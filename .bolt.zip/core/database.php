<?php
// Veritabanı bağlantı bilgileri (DOĞRUDAN BURAYA YAZ)
$db_host = "localhost";
$db_name = "herguswp_hergunpazar_db";
$db_user = "herguswp_beyyyyzadem";
$db_pass = "223145"; // ŞİFRENİZİ YAZIN

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    // Basit hata mesajı
    die("Veritabanı bağlantı hatası! Lütfen daha sonra tekrar deneyin.");
    
    // Geliştirici için detay (canlıda kapatın)
    // error_log("DB Error: " . $e->getMessage());
}
?>