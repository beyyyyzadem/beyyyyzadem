<?php
// Kullanıcı oturumu yoksa login sayfasına yönlendir
if (!isset($_SESSION['user'])) {
    header('Location: /login.php'); // login sayfan bu değilse ismini değiştir
    exit;
}
