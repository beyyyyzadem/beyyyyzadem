<?php
if (session_status() === PHP_SESSION_NONE) session_start();
?>

<style>
.nav-user-menu {
    position: relative;
    display: inline-block;
}
.nav-user-dropdown {
    display: none;
    position: absolute;
    top: 100%;
    right: 0;
    background: white;
    border: 1px solid #ddd;
    width: 220px;
    z-index: 999;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}
.nav-user-menu:hover .nav-user-dropdown {
    display: block;
}
.nav-user-dropdown a {
    display: block;
    padding: 10px;
    color: #333;
    text-decoration: none;
    border-bottom: 1px solid #eee;
    font-size: 14px;
}
.nav-user-dropdown a:hover {
    background-color: #f5f5f5;
}
</style>

<nav style="padding: 10px; background-color: #f8f8f8; display: flex; justify-content: space-between;">
    <div>
        <a href="index.php"><strong>HerGünPazar</strong></a>
    </div>
    <div>
        <?php if (isset($_SESSION['user'])): ?>
            <div class="nav-user-menu">
                <a href="#" style="text-decoration: none;">
                    <?= htmlspecialchars($_SESSION['user']['name']) ?>
                </a>
                <div class="nav-user-dropdown">
                    <a href="orders.php">Tüm Siparişlerim</a>
                    <a href="profile.php">Kullanıcı Bilgilerim</a>
                    <a href="favorites.php">Favorilerim</a>
                    <a href="messages.php">Mesajlarım</a>
                    <a href="coupons.php">İndirim Kuponlarım</a>
                    <a href="settings.php">Hesap Ayarları</a>
                    <a href="#">Şanslı Çekiliş</a>
                    <a href="#">Hergunpazar Plus</a>
                    <a href="#">Hergunpazar Elite</a>
                    <a href="#">Hergunpazar Asistan</a>
                    <a href="logout.php" style="color: red;">Çıkış Yap</a>
                </div>
            </div>
        <?php else: ?>
            <a href="login.php">Giriş Yap</a> | <a href="register.php">Üye Ol</a>
        <?php endif; ?>
    </div>
</nav>
