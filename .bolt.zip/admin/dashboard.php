<?php
session_start();
require_once('../config/database.php');

// Güvenlik: sadece admin erişsin
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

// Toplam kullanıcı sayısı
$stmt = $conn->query("SELECT COUNT(*) FROM users");
$total_users = $stmt->fetchColumn();

// Toplam satıcı
$stmt = $conn->query("SELECT COUNT(*) FROM users WHERE is_seller = 1");
$total_sellers = $stmt->fetchColumn();

// Onay bekleyen satıcı
$stmt = $conn->query("SELECT COUNT(*) FROM users WHERE is_seller = 0");
$pending_sellers = $stmt->fetchColumn();

// Toplam ürün
$stmt = $conn->query("SELECT COUNT(*) FROM products");
$total_products = $stmt->fetchColumn();

// Toplam sipariş
$stmt = $conn->query("SELECT COUNT(*) FROM orders");
$total_orders = $stmt->fetchColumn();

// Toplam gelir
$stmt = $conn->query("SELECT SUM(price) FROM orders");
$total_revenue = $stmt->fetchColumn() ?: 0;
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Admin Paneli</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f6f8;
            margin: 0;
            padding: 0;
        }
        .header {
            background-color: #333;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 1100px;
            margin: 30px auto;
            padding: 20px;
        }
        .stats {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .stat-box {
            flex: 1;
            min-width: 250px;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-box h2 {
            font-size: 30px;
            color: #007BFF;
        }
        .stat-box p {
            color: #666;
        }
    </style>
</head>
<body>

<div class="header">
    <h1>📊 Admin Paneli - Genel Durum</h1>
</div>

<div class="container">
    <div class="stats">
        <div class="stat-box">
            <h2><?= $total_users ?></h2>
            <p>Kayıtlı Kullanıcı</p>
        </div>
        <div class="stat-box">
            <h2><?= $total_sellers ?></h2>
            <p>Aktif Satıcı</p>
        </div>
        <div class="stat-box">
            <h2><?= $pending_sellers ?></h2>
            <p>Onay Bekleyen Satıcı</p>
        </div>
        <div class="stat-box">
            <h2><?= $total_products ?></h2>
            <p>Toplam Ürün</p>
        </div>
        <div class="stat-box">
            <h2><?= $total_orders ?></h2>
            <p>Toplam Sipariş</p>
        </div>
        <div class="stat-box">
            <h2><?= number_format($total_revenue, 2, ',', '.') ?> ₺</h2>
            <p>Toplam Gelir</p>
        </div>
    </div>
</div>

</body>
</html>
