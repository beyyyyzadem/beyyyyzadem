<?php
session_start();
require_once('../config/database.php');
include 'auth.php'; // Oturum kontrolü
include('includes/navbar.php'); // Navigasyon

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$seller_id = $_SESSION['user_id'];

// Kullanıcı bilgilerini çek
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->execute([$seller_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

    if ($password) {
        $stmt = $conn->prepare("UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?");
        $stmt->execute([$name, $email, $password, $seller_id]);
    } else {
        $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
        $stmt->execute([$name, $email, $seller_id]);
    }

    $success = "Profil başarıyla güncellendi!";
    $_SESSION['user_name'] = $name;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Profil Düzenle</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 30px; }
        .form-box {
            max-width: 500px;
            margin: auto;
            background: #fff;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; color: #333; }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%; padding: 10px; margin: 10px 0 20px; border: 1px solid #ccc; border-radius: 6px;
        }
        button {
            background: #0066cc; color: white; border: none; padding: 12px; border-radius: 6px;
            width: 100%; font-size: 16px; cursor: pointer;
        }
        .success { color: green; text-align: center; margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="form-box">
    <h2>🧑 Profilini Düzenle</h2>

    <?php if (isset($success)): ?>
        <p class="success"><?= $success ?></p>
    <?php endif; ?>

    <form method="post">
        <label>Adınız Soyadınız:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>

        <label>E-Posta:</label>
        <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>

        <label>Yeni Şifre (değiştirmek istemiyorsan boş bırak):</label>
        <input type="password" name="password">

        <button type="submit">Güncelle</button>
    </form>
</div>

</body>
</html>
