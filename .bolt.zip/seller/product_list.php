<?php
include 'auth.php';
require_once '../config/database.php';

$seller_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT id, title, price, image FROM products WHERE seller_id = ? ORDER BY created_at DESC");
$stmt->execute([$seller_id]);
$products = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ürünlerim</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 30px; background: #f9f9f9; }
        h2 { color: #444; }
        .product-box {
            display: grid;
            grid-template-columns: 100px 1fr 150px;
            align-items: center;
            background: #fff;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 10px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
        }
        img { width: 80px; height: 80px; object-fit: cover; border-radius: 8px; }
        .actions a {
            margin-right: 10px;
            text-decoration: none;
            color: white;
            background: #007bff;
            padding: 6px 10px;
            border-radius: 5px;
            font-size: 14px;
        }
        .actions a.delete {
            background: #dc3545;
        }
    </style>
</head>
<body>

<h2>🛍️ Ürünlerim</h2>
<a href="product_add.php" style="text-decoration:none; background:green; padding:10px 15px; color:white; border-radius:6px;">➕ Yeni Ürün Ekle</a>
<br><br>

<?php if (count($products) > 0): ?>
    <?php foreach ($products as $product): ?>
        <div class="product-box">
            <img src="../<?= htmlspecialchars($product['image']) ?>" alt="Görsel">
            <div>
                <strong><?= htmlspecialchars($product['title']) ?></strong><br>
                <span><?= number_format($product['price'], 2) ?> TL</span>
            </div>
            <div class="actions">
                <a href="product_edit.php?id=<?= $product['id'] ?>">✏️ Düzenle</a>
                <a href="product_delete.php?id=<?= $product['id'] ?>" class="delete" onclick="return confirm('Silmek istediğinize emin misiniz?')">🗑️ Sil</a>
            </div>
        </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>Henüz ürün eklemediniz.</p>
<?php endif; ?>

</body>
</html>
