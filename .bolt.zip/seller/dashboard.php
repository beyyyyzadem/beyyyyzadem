<?php
include 'auth.php';
require_once '../config/database.php';

$seller_id = $_SESSION['user_id'];

// Toplam ürün sayısı
$stmt = $conn->prepare("SELECT COUNT(*) FROM products WHERE seller_id = ?");
$stmt->execute([$seller_id]);
$product_count = $stmt->fetchColumn();

// Toplam sipariş sayısı
$stmt = $conn->prepare("
    SELECT COUNT(*) FROM orders o 
    JOIN products p ON o.product_id = p.id 
    WHERE p.seller_id = ?
");
$stmt->execute([$seller_id]);
$order_count = $stmt->fetchColumn();

// Toplam kazanç
$stmt = $conn->prepare("
    SELECT SUM(o.total_price) FROM orders o 
    JOIN products p ON o.product_id = p.id 
    WHERE p.seller_id = ?
");
$stmt->execute([$seller_id]);
$total_earnings = $stmt->fetchColumn();
$total_earnings = $total_earnings ? number_format($total_earnings, 2, ',', '.') : '0,00';
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Satıcı Paneli</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        h2 {
            margin-top: 0;
        }

        .stats-container {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .stat-box {
            flex: 1;
            padding: 20px;
            border-radius: 10px;
            color: white;
            text-align: center;
            min-width: 250px;
        }

        .stat-products { background-color: #0066cc; }
        .stat-orders { background-color: #28a745; }
        .stat-earnings { background-color: #ff9900; }

        .stat-box h3 {
            margin-bottom: 10px;
            font-size: 20px;
        }

        .stat-box p {
            font-size: 28px;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <h2>📊 Genel Bakış</h2>

    <div class="stats-container">
        <div class="stat-box stat-products">
            <h3>Ürün Sayısı</h3>
            <p><?= $product_count ?></p>
        </div>
        <div class="stat-box stat-orders">
            <h3>Sipariş Sayısı</h3>
            <p><?= $order_count ?></p>
        </div>
        <div class="stat-box stat-earnings">
            <h3>Toplam Kazanç</h3>
            <p><?= $total_earnings ?> TL</p>
        </div>
    </div>

    <!-- Buraya dilersen grafik/duyuru/ek tablo eklenebilir -->

</body>
</html>
