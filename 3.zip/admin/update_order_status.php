<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['admin_logged_in'])) {
    echo "Yetkisiz erişim!";
    exit;
}

if (isset($_GET['id']) && isset($_GET['status'])) {
    $id = intval($_GET['id']);
    $status = $_GET['status'];

    $query = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $query->execute([$status, $id]);

    header("Location: orders.php");
    exit;
} else {
    echo "Eksik bilgi!";
}
?>
