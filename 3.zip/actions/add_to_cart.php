<?php
session_start();
include "../includes/config.php";

// Kullanıcı girişi kontrolü
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Gelen verileri al
if (!isset($_POST['product_id'], $_POST['quantity'])) {
    die("Eksik veri gönderildi.");
}

$product_id = (int) $_POST['product_id'];
$quantity = (int) $_POST['quantity'];

// Ürün kontrolü
$stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
$stmt->execute([$product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    die("Ürün bulunamadı.");
}

if ($quantity < 1 || $quantity > $product['stock']) {
    die("Geçersiz miktar.");
}

// Sepette ürün zaten var mı?
$stmt = $conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND product_id = ?");
$stmt->execute([$user_id, $product_id]);
$existing = $stmt->fetch(PDO::FETCH_ASSOC);

if ($existing) {
    // Varsa, miktarı güncelle
    $new_quantity = $existing['quantity'] + $quantity;
    if ($new_quantity > $product['stock']) {
        $new_quantity = $product['stock'];
    }

    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
    $stmt->execute([$new_quantity, $existing['id']]);
} else {
    // Yoksa, sepete ekle
    $stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $product_id, $quantity]);
}

header("Location: ../cart.php");
exit;
