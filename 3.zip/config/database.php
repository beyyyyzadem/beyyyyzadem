<?php
$host = 'localhost';
$db   = 'herguswp_hergunpazar_db'; // doğru veritabanı adın bu
$user = 'herguswp_beyyyyzadem';     // senin kullanıcı adın
$pass = '223145223145M.m';          // şifre
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $conn = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo 'Veritabanı bağlantı hatası: ' . $e->getMessage();
    exit;
}
?>
