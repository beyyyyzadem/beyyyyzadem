<?php
include 'auth.php';
require_once '../config/database.php';

$seller_id = $_SESSION['user_id'];

// Satıcının ürünlerine ait siparişleri çek
$stmt = $conn->prepare("
    SELECT o.id AS order_id, u.name AS customer_name, p.name AS product_name, o.quantity, o.total_price, o.status, o.created_at
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN products p ON o.product_id = p.id
    WHERE p.seller_id = ?
    ORDER BY o.created_at DESC
");
$stmt->execute([$seller_id]);
$orders = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Siparişlerim</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
        table { width: 100%; background: white; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ccc; text-align: center; }
        th { background-color: #0066cc; color: white; }
        form { margin: 0; }
        select, button { padding: 5px; }
    </style>
</head>
<body>

    <h2>📦 Siparişlerim</h2>

    <?php if (isset($_GET['updated'])): ?>
        <p style="color: green;">Sipariş durumu güncellendi!</p>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>Müşteri</th>
                <th>Ürün</th>
                <th>Adet</th>
                <th>Tutar</th>
                <th>Durum</th>
                <th>Tarih</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?= htmlspecialchars($order['customer_name']) ?></td>
                    <td><?= htmlspecialchars($order['product_name']) ?></td>
                    <td><?= $order['quantity'] ?></td>
                    <td><?= number_format($order['total_price'], 2) ?> TL</td>
                    <td><?= htmlspecialchars($order['status']) ?></td>
                    <td><?= $order['created_at'] ?></td>
                    <td>
                        <form method="post" action="order_status_update.php">
                            <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                            <select name="status">
                                <option value="Hazırlanıyor" <?= $order['status'] == 'Hazırlanıyor' ? 'selected' : '' ?>>Hazırlanıyor</option>
                                <option value="Kargoya Verildi" <?= $order['status'] == 'Kargoya Verildi' ? 'selected' : '' ?>>Kargoya Verildi</option>
                                <option value="Teslim Edildi" <?= $order['status'] == 'Teslim Edildi' ? 'selected' : '' ?>>Teslim Edildi</option>
                            </select>
                            <button type="submit">Güncelle</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (empty($orders)): ?>
                <tr><td colspan="7">Henüz siparişiniz yok.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>

</body>
</html>
