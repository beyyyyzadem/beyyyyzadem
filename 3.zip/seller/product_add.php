<?php 
include 'auth.php';
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $seller_id = $_SESSION['user_id'];
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);
    
    // Görsel yükleme işlemi
    $image = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = '../assets/uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $filename = uniqid() . '.' . $ext;
        $target_file = $upload_dir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image = 'assets/uploads/' . $filename;
        }
    }

    // Veritabanına kayıt
    $stmt = $conn->prepare("INSERT INTO products (seller_id, title, description, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$seller_id, $title, $description, $price, $stock, $image]);

    $success = "Ürün başarıyla eklendi!";
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ürün Ekle</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 30px; }
        .form-box {
            max-width: 600px; margin: auto; background: #fff;
            padding: 25px; border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; }
        input[type="text"], input[type="number"], textarea, input[type="file"] {
            width: 100%; padding: 10px; margin: 10px 0 20px;
            border: 1px solid #ccc; border-radius: 6px;
        }
        button {
            background: #28a745; color: white; border: none;
            padding: 12px; border-radius: 6px; width: 100%;
            font-size: 16px; cursor: pointer;
        }
        .success { color: green; text-align: center; margin-bottom: 15px; }
    </style>
</head>
<body>

<div class="form-box">
    <h2>➕ Yeni Ürün Ekle</h2>
    
    <?php if (isset($success)): ?>
        <p class="success"><?= $success ?></p>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <label>Ürün Başlığı:</label>
        <input type="text" name="title" required>

        <label>Açıklama:</label>
        <textarea name="description" rows="5" required></textarea>

        <label>Fiyat (₺):</label>
        <input type="number" name="price" step="0.01" required>

        <label>Stok Miktarı:</label>
        <input type="number" name="stock" required>

        <label>Ürün Görseli:</label>
        <input type="file" name="image">

        <button type="submit">Ürünü Kaydet</button>
    </form>
</div>

</body>
</html>
