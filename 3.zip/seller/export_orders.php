<?php
include 'auth.php';
require_once '../config/database.php';

$seller_id = $_SESSION['user_id'];

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=satis_raporu.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['Müşteri Adı', 'Ürün', 'Adet', 'Toplam Tutar (TL)', 'Durum', 'Sipariş Tarihi']);

$stmt = $conn->prepare("
    SELECT u.name AS customer_name, p.name AS product_name, o.quantity, o.total_price, o.status, o.created_at
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN products p ON o.product_id = p.id
    WHERE p.seller_id = ?
    ORDER BY o.created_at DESC
");
$stmt->execute([$seller_id]);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, [
        $row['customer_name'],
        $row['product_name'],
        $row['quantity'],
        number_format($row['total_price'], 2, ',', '.'),
        $row['status'],
        $row['created_at']
    ]);
}

fclose($output);
exit;
