<?php
include 'auth.php';
require_once '../config/database.php';

if (!isset($_GET['id'])) {
    echo "Ürün ID bulunamadı.";
    exit;
}

$product_id = (int) $_GET['id'];
$seller_id = $_SESSION['user_id'];

// Ürün bilgilerini çek
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND seller_id = ?");
$stmt->execute([$product_id, $seller_id]);
$product = $stmt->fetch();

if (!$product) {
    echo "Ürün bulunamadı veya yetkiniz yok.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ürün Detayı</title>
    <style>
        body { font-family: Arial; background: #f9f9f9; padding: 20px; }
        .box {
            max-width: 700px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        img {
            max-width: 100%; height: auto; border-radius: 10px; margin-bottom: 20px;
        }
        h2 { margin-bottom: 10px; color: #333; }
        p { line-height: 1.6; }
        .label { font-weight: bold; color: #555; }
    </style>
</head>
<body>

<div class="box">
    <h2>🛍️ <?= htmlspecialchars($product['name']) ?></h2>

    <?php if (!empty($product['image_url'])): ?>
        <img src="../<?= htmlspecialchars($product['image_url']) ?>" alt="Ürün Görseli">
    <?php endif; ?>

    <p><span class="label">Açıklama:</span> <?= nl2br(htmlspecialchars($product['description'])) ?></p>
    <p><span class="label">Fiyat:</span> <?= number_format($product['price'], 2) ?> TL</p>
    <p><span class="label">Stok:</span> <?= $product['stock'] ?></p>
    <p><span class="label">Kategori:</span> <?= htmlspecialchars($product['category']) ?></p>
    <p><span class="label">Eklenme Tarihi:</span> <?= $product['created_at'] ?></p>
</div>

</body>
</html>
