<?php
require_once '../includes/init.php'; // Tek merkezden session başlatılır

// Veritabanı bağlantısı
require_once '../config/database.php';

// Giriş yapılmamışsa yönlendir
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $stmt = $conn->prepare("SELECT is_seller FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || (int)$user['is_seller'] !== 1) {
        echo "❌ Bu sayfaya yalnızca satıcılar erişebilir.";
        exit;
    }

} catch (PDOException $e) {
    // Hata log'lanabilir ama kullanıcıya gösterilmez
    error_log("Satıcı kontrol hatası: " . $e->getMessage());
    echo "⚠️ Bir hata oluştu, lütfen tekrar deneyin.";
    exit;
}
