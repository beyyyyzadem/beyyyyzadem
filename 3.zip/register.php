<?php
session_start();
require_once 'includes/config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];

    if (empty($name) || empty($email) || empty($password) || empty($confirm)) {
        $error = "Lütfen tüm alanları doldurun.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Geçerli bir e-posta adresi girin.";
    } elseif ($password !== $confirm) {
        $error = "Şifreler uyuşmuyor.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);

        if ($stmt->rowCount() > 0) {
            $error = "Bu e-posta adresi zaten kullanılıyor.";
        } else {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
            $stmt->execute([$name, $email, $hashedPassword]);

            $_SESSION['user'] = [
                'id' => $conn->lastInsertId(),
                'name' => $name
            ];

            header("Location: index.php");
            exit;
        }
    }
}
?>

<?php include 'includes/navbar.php'; ?>

<div style="max-width: 500px; margin: 60px auto; font-family: Arial, sans-serif;">
    <h2>Kayıt Ol</h2>
    <?php if (isset($error)): ?>
        <div style="color: red; margin-bottom: 10px;"><?= $error ?></div>
    <?php endif; ?>
    <form method="post">
        <label>Ad Soyad:</label>
        <input type="text" name="name" required style="width: 100%; padding: 8px; margin-bottom: 10px;">
        <label>E-posta:</label>
        <input type="email" name="email" required style="width: 100%; padding: 8px; margin-bottom: 10px;">
        <label>Şifre:</label>
        <input type="password" name="password" required style="width: 100%; padding: 8px; margin-bottom: 10px;">
        <label>Şifre Tekrar:</label>
        <input type="password" name="confirm_password" required style="width: 100%; padding: 8px; margin-bottom: 15px;">
        <button type="submit" style="padding: 10px 20px; background-color: #27ae60; color: white; border: none;">Kayıt Ol</button>
    </form>
    <p style="margin-top: 15px;">Zaten üye misiniz? <a href="login.php">Giriş yap</a></p>
</div>
