<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['admin_logged_in'])) {
    echo "Yetkisiz erişim!";
    exit;
}

if (!isset($_GET['id']) || !isset($_GET['action'])) {
    echo "Eksik parametre.";
    exit;
}

$id = intval($_GET['id']);
$action = $_GET['action'];

if ($action === 'approve') {
    // Satıcıyı onayla
    $stmt = $conn->prepare("UPDATE seller_requests SET status = 'onaylandı' WHERE id = ?");
    $stmt->execute([$id]);

    // Kullanıcıyı satıcı yap
    $req = $conn->prepare("SELECT user_id FROM seller_requests WHERE id = ?");
    $req->execute([$id]);
    $user = $req->fetch(PDO::FETCH_ASSOC);

    $updateUser = $conn->prepare("UPDATE users SET is_seller = 1 WHERE id = ?");
    $updateUser->execute([$user['user_id']]);

} elseif ($action === 'reject') {
    $stmt = $conn->prepare("UPDATE seller_requests SET status = 'reddedildi' WHERE id = ?");
    $stmt->execute([$id]);
}

header("Location: seller_requests.php");
exit;
