<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['admin_logged_in'])) {
    echo "Yetkisiz erişim!";
    exit;
}

if (!isset($_GET['id'])) {
    echo "Sipariş ID belirtilmedi.";
    exit;
}

$order_id = intval($_GET['id']);

// Sipariş bilgisi
$orderStmt = $conn->prepare("SELECT o.*, u.name, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$orderStmt->execute([$order_id]);
$order = $orderStmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "Sipariş bulunamadı.";
    exit;
}

// Sipariş ürünleri
$itemStmt = $conn->prepare("
    SELECT oi.*, p.title 
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    WHERE oi.order_id = ?");
$itemStmt->execute([$order_id]);
$items = $itemStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Sipariş Detayı #<?= $order_id ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
    <h2>Sipariş Detayı: #<?= $order_id ?></h2>
    <p><strong>Kullanıcı:</strong> <?= htmlspecialchars($order['name']) ?> (<?= $order['email'] ?>)</p>
    <p><strong>Durum:</strong> <?= htmlspecialchars($order['status']) ?></p>
    <p><strong>Tarih:</strong> <?= $order['created_at'] ?></p>
    <p><strong>Toplam Tutar:</strong> <?= number_format($order['total_price'], 2) ?> TL</p>

    <hr>
    <h4>Ürünler</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Ürün</th>
                <th>Adet</th>
                <th>Birim Fiyat</th>
                <th>Toplam</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['title']) ?></td>
                <td><?= $item['quantity'] ?></td>
                <td><?= number_format($item['price'], 2) ?> TL</td>
                <td><?= number_format($item['price'] * $item['quantity'], 2) ?> TL</td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <a href="orders.php" class="btn btn-secondary">← Geri Dön</a>
</body>
</html>
