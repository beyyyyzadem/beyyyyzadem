<?php
session_start();
include '../config/database.php';

if (!isset($_SESSION['admin_logged_in'])) {
    echo "Yetkisiz erişim!";
    exit;
}

$requests = $conn->query("
    SELECT r.*, u.name, u.email 
    FROM seller_requests r 
    JOIN users u ON r.user_id = u.id 
    ORDER BY r.requested_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Satıcı Başvuruları</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
    <h2>Satıcı Başvuruları</h2>
    <table class="table table-bordered table-hover mt-4">
        <thead>
            <tr>
                <th>Kullanıcı</th>
                <th>Mağaza Adı</th>
                <th>Açıklama</th>
                <th>Durum</th>
                <th>Tarih</th>
                <th>İşlem</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ($requests as $req): ?>
            <tr>
                <td><?= htmlspecialchars($req['name']) ?> (<?= $req['email'] ?>)</td>
                <td><?= htmlspecialchars($req['store_name']) ?></td>
                <td><?= htmlspecialchars($req['description']) ?></td>
                <td><?= htmlspecialchars($req['status']) ?></td>
                <td><?= $req['requested_at'] ?></td>
                <td>
                    <?php if ($req['status'] === 'beklemede'): ?>
                        <a href="seller_request.php?id=<?= $req['id'] ?>&action=approve" class="btn btn-success btn-sm">Onayla</a>
                        <a href="seller_request.php?id=<?= $req['id'] ?>&action=reject" class="btn btn-danger btn-sm">Reddet</a>
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
