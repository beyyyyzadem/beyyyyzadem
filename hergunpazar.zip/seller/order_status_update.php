<?php
include 'auth.php';
require_once '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = intval($_POST['order_id']);
    $new_status = trim($_POST['status']);
    $seller_id = $_SESSION['user_id'];

    // Siparişin satıcıya ait olup olmadığını kontrol et
    $stmt = $conn->prepare("
        SELECT o.id
        FROM orders o
        JOIN products p ON o.product_id = p.id
        WHERE o.id = ? AND p.seller_id = ?
    ");
    $stmt->execute([$order_id, $seller_id]);
    $valid = $stmt->fetch();

    if ($valid) {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $order_id]);

        header("Location: orders.php?success=1");
        exit;
    } else {
        header("Location: orders.php?error=1");
        exit;
    }
} else {
    header("Location: orders.php");
    exit;
}
?>
