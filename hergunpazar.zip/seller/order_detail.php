<?php
include 'auth.php';
require_once '../config/database.php';

if (!isset($_GET['id'])) {
    echo "Sipariş ID belirtilmedi.";
    exit;
}

$order_id = intval($_GET['id']);
$seller_id = $_SESSION['user_id'];

// Sipariş detaylarını al
$stmt = $conn->prepare("
    SELECT o.id, o.quantity, o.total_price, o.status, o.created_at,
           u.name AS customer_name, u.email AS customer_email,
           p.name AS product_name, p.description, p.price
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN products p ON o.product_id = p.id
    WHERE o.id = ? AND p.seller_id = ?
");
$stmt->execute([$order_id, $seller_id]);
$order = $stmt->fetch();

if (!$order) {
    echo "Sipariş bulunamadı ya da yetkiniz yok.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sipariş Detayı</title>
    <style>
        body { font-family: Arial; background: #f9f9f9; padding: 20px; }
        .detail-box {
            max-width: 700px; margin: auto; background: white;
            padding: 20px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h2 { color: #333; margin-bottom: 20px; }
        .detail-item { margin-bottom: 10px; }
        .label { font-weight: bold; color: #555; display: inline-block; width: 160px; }
    </style>
</head>
<body>

<div class="detail-box">
    <h2>📄 Sipariş Detayı (#<?= $order['id'] ?>)</h2>

    <div class="detail-item"><span class="label">Müşteri Adı:</span> <?= htmlspecialchars($order['customer_name']) ?></div>
    <div class="detail-item"><span class="label">E-posta:</span> <?= htmlspecialchars($order['customer_email']) ?></div>
    <div class="detail-item"><span class="label">Ürün:</span> <?= htmlspecialchars($order['product_name']) ?></div>
    <div class="detail-item"><span class="label">Açıklama:</span> <?= htmlspecialchars($order['description']) ?></div>
    <div class="detail-item"><span class="label">Birim Fiyat:</span> <?= number_format($order['price'], 2) ?> TL</div>
    <div class="detail-item"><span class="label">Adet:</span> <?= $order['quantity'] ?></div>
    <div class="detail-item"><span class="label">Toplam Tutar:</span> <?= number_format($order['total_price'], 2) ?> TL</div>
    <div class="detail-item"><span class="label">Durum:</span> <?= htmlspecialchars($order['status']) ?></div>
    <div class="detail-item"><span class="label">Sipariş Tarihi:</span> <?= $order['created_at'] ?></div>

    <br><a href="orders.php" style="text-decoration: none; color: #0066cc;">← Geri dön</a>
</div>

</body>
</html>
