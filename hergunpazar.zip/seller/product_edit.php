<?php
include 'auth.php';
require_once '../config/database.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Geçersiz ürün ID");
}

$product_id = $_GET['id'];
$seller_id = $_SESSION['user_id'];

// Ürünü al
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND seller_id = ?");
$stmt->execute([$product_id, $seller_id]);
$product = $stmt->fetch();

if (!$product) {
    die("Ürün bulunamadı");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $stock = intval($_POST['stock']);

    // Görsel yükleme kontrolü
    if ($_FILES['image']['size'] > 0) {
        $imagePath = 'uploads/' . time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], "../" . $imagePath);
    } else {
        $imagePath = $product['image'];
    }

    // Güncelle
    $stmt = $conn->prepare("UPDATE products SET title = ?, description = ?, price = ?, stock = ?, image = ? WHERE id = ? AND seller_id = ?");
    $stmt->execute([$title, $description, $price, $stock, $imagePath, $product_id, $seller_id]);

    $success = "Ürün başarıyla güncellendi.";
    // En son veriyi tekrar al
    $stmt = $conn->prepare("SELECT * FROM products WHERE id = ? AND seller_id = ?");
    $stmt->execute([$product_id, $seller_id]);
    $product = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Ürünü Düzenle</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; padding: 30px; }
        .form-box {
            max-width: 600px; margin: auto; background: #fff;
            padding: 25px; border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        input, textarea {
            width: 100%; padding: 10px; margin-bottom: 15px;
            border: 1px solid #ccc; border-radius: 6px;
        }
        button {
            background: #28a745; color: white; border: none;
            padding: 12px; border-radius: 6px; width: 100%;
            font-size: 16px; cursor: pointer;
        }
        img.preview {
            height: 100px; margin-bottom: 10px;
            border-radius: 8px;
        }
        .success { color: green; text-align: center; margin-bottom: 10px; }
    </style>
</head>
<body>

<div class="form-box">
    <h2>✏️ Ürünü Güncelle</h2>

    <?php if (isset($success)): ?>
        <p class="success"><?= $success ?></p>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
        <label>Başlık:</label>
        <input type="text" name="title" value="<?= htmlspecialchars($product['title']) ?>" required>

        <label>Açıklama:</label>
        <textarea name="description" required><?= htmlspecialchars($product['description']) ?></textarea>

        <label>Fiyat (₺):</label>
        <input type="number" step="0.01" name="price" value="<?= $product['price'] ?>" required>

        <label>Stok:</label>
        <input type="number" name="stock" value="<?= $product['stock'] ?>" required>

        <label>Mevcut Görsel:</label><br>
        <?php if ($product['image']): ?>
            <img src="../<?= htmlspecialchars($product['image']) ?>" class="preview"><br>
        <?php endif; ?>

        <label>Yeni Görsel (değiştirmek istersen):</label>
        <input type="file" name="image">

        <button type="submit">Güncelle</button>
    </form>
</div>

</body>
</html>
