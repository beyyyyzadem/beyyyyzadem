<?php
// Session'ı güvenli şekilde başlat
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// İçerik tipi zorlaması yapılmıyor, HTML veya JSON olabilir.
// Gerekirse buraya config, db bağlantısı vs. dahil edilebilir.
