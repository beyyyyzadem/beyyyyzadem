<?php 
$host = 'localhost';
$db   = 'herguswp_hergunpazar_db';
$user = 'herguswp_beyyyyzadem';
$pass = '223145223145M.m';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// PDO bağlantısı (güvenli bağlantı, login.php gibi dosyalarda kullanılabilir)
try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
} catch (PDOException $e) {
    die("PDO bağlantı hatası: " . $e->getMessage());
}

// İkinci bağlantı objesi gerekiyorsa (örneğin mysqli yerine alternatif olarak)
$conn = $pdo;
