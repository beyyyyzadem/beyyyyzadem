<?php
session_start();
require 'core/database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // TEST: Sabit kullanıcı ile giriş (geçici)
    if ($email === "test@hergunpazar.com" && $password === "test123") {
        $_SESSION['user'] = "Test Kullanıcı";
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Geçersiz giriş!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Giriş Yap</title>
</head>
<body>
    <?php if (isset($error)): ?>
        <p style="color:red"><?= $error ?></p>
    <?php endif; ?>
    
    <form method="POST">
        <input type="email" name="email" placeholder="E-posta" required>
        <input type="password" name="password" placeholder="Şifre" required>
        <button type="submit">Giriş Yap</button>
    </form>
</body>
</html>