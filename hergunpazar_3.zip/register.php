<?php
session_start();
require_once "config/db.php";

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirm  = trim($_POST['confirm']);

    if (!empty($name) && !empty($email) && !empty($password) && !empty($confirm)) {
        if ($password === $confirm) {
            // Aynı email var mı kontrol et
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows === 0) {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $insert = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
                $insert->bind_param("sss", $name, $email, $hashed_password);

                if ($insert->execute()) {
                    // Başarıyla kaydolduysa login yapsın
                    $_SESSION['user_id'] = $insert->insert_id;
                    $_SESSION['user_name'] = $name;
                    $_SESSION['user_email'] = $email;
                    header("Location: index.php");
                    exit();
                } else {
                    $message = "Kayıt işlemi sırasında hata oluştu.";
                }
            } else {
                $message = "Bu e-posta zaten kayıtlı.";
            }
        } else {
            $message = "Şifreler uyuşmuyor.";
        }
    } else {
        $message = "Tüm alanları doldurun.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Üye Ol</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Üye Ol</h2>
    <?php if (!empty($message)) echo "<p style='color:red;'>$message</p>"; ?>

    <form action="register.php" method="POST">
        <label for="name">Ad Soyad:</label><br>
        <input type="text" name="name" required><br><br>

        <label for="email">E-posta:</label><br>
        <input type="email" name="email" required><br><br>

        <label for="password">Şifre:</label><br>
        <input type="password" name="password" required><br><br>

        <label for="confirm">Şifre (Tekrar):</label><br>
        <input type="password" name="confirm" required><br><br>

        <button type="submit">Üye Ol</button>
    </form>
</div>

</body>
</html>
