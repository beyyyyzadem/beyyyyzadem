<?php
require 'vendor/autoload.php';

use Dompdf\Dompdf;
use Dompdf\Options;

$siparis_id = $_GET['siparis_id'] ?? null;

if (!$siparis_id) {
    die("Geçersiz sipariş.");
}

// Burada örnek veri kullanalım, gerçek sistemde veritabanı bağlantısı olacak
// TODO: siparis_id ile veritabanından sipariş bilgilerini çek
$tarih = '2025-07-25';
$musteri_adi = 'Mehmet Eselioğlu';
$urunler = [
    ['ad' => 'Bluetooth Kulaklık', 'adet' => 1, 'fiyat' => 199.90],
    ['ad' => 'Kablolu Mouse', 'adet' => 2, 'fiyat' => 130.00]
];

// Fatura içeriği HTML olarak
$fatura_html = '
<h1>FATURA</h1>
<p><strong>Sipariş No:</strong> #' . $siparis_id . '</p>
<p><strong>Tarih:</strong> ' . $tarih . '</p>
<p><strong>Müşteri:</strong> ' . htmlspecialchars($musteri_adi) . '</p>
<table width="100%" border="1" cellspacing="0" cellpadding="5">
    <thead>
        <tr>
            <th>Ürün</th>
            <th>Adet</th>
            <th>Birim Fiyat</th>
            <th>Toplam</th>
        </tr>
    </thead>
    <tbody>';
$toplam = 0;
foreach ($urunler as $urun) {
    $satir_toplam = $urun['adet'] * $urun['fiyat'];
    $toplam += $satir_toplam;
    $fatura_html .= '
        <tr>
            <td>' . htmlspecialchars($urun['ad']) . '</td>
            <td>' . $urun['adet'] . '</td>
            <td>' . number_format($urun['fiyat'], 2) . ' TL</td>
            <td>' . number_format($satir_toplam, 2) . ' TL</td>
        </tr>';
}
$fatura_html .= '
        <tr>
            <td colspan="3" align="right"><strong>Genel Toplam:</strong></td>
            <td><strong>' . number_format($toplam, 2) . ' TL</strong></td>
        </tr>
    </tbody>
</table>
<p style="margin-top: 50px;">Teşekkür ederiz.</p>
';

// PDF oluştur
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);
$dompdf->loadHtml($fatura_html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();
$dompdf->stream("fatura_{$siparis_id}.pdf", ["Attachment" => true]);
