<?php
session_start();
require_once "config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Kart silme
if (isset($_GET['sil'])) {
    $id = (int)$_GET['sil'];
    $stmt = $conn->prepare("DELETE FROM kartlar WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $stmt->close();
    $message = "Kart silindi.";
}

// Kart ekleme / güncelleme
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $kart_sahibi = trim($_POST['kart_sahibi']);
    $kart_numarasi = trim($_POST['kart_numarasi']);

    if (!empty($kart_sahibi) && !empty($kart_numarasi)) {
        if (!empty($_POST['kart_id'])) {
            // Güncelle
            $kart_id = (int)$_POST['kart_id'];
            $stmt = $conn->prepare("UPDATE kartlar SET kart_sahibi=?, kart_numarasi=? WHERE id=? AND user_id=?");
            $stmt->bind_param("ssii", $kart_sahibi, $kart_numarasi, $kart_id, $user_id);
            $stmt->execute();
            $stmt->close();
            $message = "Kart güncellendi.";
        } else {
            // Yeni kart ekle
            $stmt = $conn->prepare("INSERT INTO kartlar (user_id, kart_sahibi, kart_numarasi) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $user_id, $kart_sahibi, $kart_numarasi);
            $stmt->execute();
            $stmt->close();
            $message = "Kart eklendi.";
        }
    }
}

// Tek kart çek (düzenleme için)
$duzenle_kart = null;
if (isset($_GET['duzenle'])) {
    $id = (int)$_GET['duzenle'];
    $stmt = $conn->prepare("SELECT id, kart_sahibi, kart_numarasi FROM kartlar WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $stmt->bind_result($kid, $ksahibi, $knumara);
    if ($stmt->fetch()) {
        $duzenle_kart = ['id' => $kid, 'kart_sahibi' => $ksahibi, 'kart_numarasi' => $knumara];
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kartlarım</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Kartlarım</h2>
    <?php if (!empty($message)) echo "<p style='color:green;'>$message</p>"; ?>

    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>Kart Sahibi</th>
            <th>Kart Numarası</th>
            <th>İşlem</th>
        </tr>
        <?php
        $stmt = $conn->prepare("SELECT id, kart_sahibi, kart_numarasi FROM kartlar WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($id, $sahip, $numara);
        while ($stmt->fetch()) {
            echo "<tr>
                    <td>" . htmlspecialchars($sahip) . "</td>
                    <td>" . htmlspecialchars($numara) . "</td>
                    <td>
                        <a href='kartlarim.php?duzenle=$id'>Düzenle</a> | 
                        <a href='kartlarim.php?sil=$id' onclick='return confirm(\"Silmek istediğinize emin misiniz?\")'>Sil</a>
                    </td>
                  </tr>";
        }
        $stmt->close();
        ?>
    </table>

    <hr>
    <h3><?php echo $duzenle_kart ? "Kart Güncelle" : "Yeni Kart Ekle"; ?></h3>
    <form method="post" action="">
        <input type="hidden" name="kart_id" value="<?php echo $duzenle_kart['id'] ?? ''; ?>">
        <label>Kart Sahibi:</label><br>
        <input type="text" name="kart_sahibi" value="<?php echo $duzenle_kart['kart_sahibi'] ?? ''; ?>" required><br><br>

        <label>Kart Numarası:</label><br>
        <input type="text" name="kart_numarasi" value="<?php echo $duzenle_kart['kart_numarasi'] ?? ''; ?>" required><br><br>

        <button type="submit"><?php echo $duzenle_kart ? "Güncelle" : "Ekle"; ?></button>
    </form>
</div>

</body>
</html>
