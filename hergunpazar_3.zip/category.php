<?php
session_start();
require_once 'includes/db.php'; // veritabanı bağlantısı

$categories = [
    'kadin' => ['title' => 'Kadın', 'subs' => ['giyim', 'ayakkabi', 'canta', 'aksesuar']],
    'erkek' => ['title' => 'Erkek', 'subs' => ['giyim', 'ayakkabi', 'aksesuar']],
    'elektronik' => ['title' => 'Elektronik', 'subs' => ['telefon', 'bilgisayar', 'tv', 'beyaz-esya']],
    'ev-yasam' => ['title' => 'Ev & Yaşam', 'subs' => ['mobilya', 'dekorasyon', 'mutfak', 'aydinlatma']],
    'anne-cocuk' => ['title' => 'Anne & Çocuk', 'subs' => ['bebek-giyim', 'oyuncak', 'emzirme', 'bebek-arabasi']]
];

$catKey = $_GET['cat'] ?? '';
$subKey = $_GET['sub'] ?? '';
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kategori: <?php echo ucfirst($catKey); ?></title>
    <style>
        body {
            font-family: Arial;
            background: #f8f8f8;
            margin: 0;
            padding: 0;
        }
        header, footer {
            background: #6a11cb;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .subcategories {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .subcategories a {
            padding: 10px 15px;
            background: white;
            border: 1px solid #6a11cb;
            color: #6a11cb;
            border-radius: 20px;
            text-decoration: none;
        }
        .subcategories a:hover {
            background: #6a11cb;
            color: white;
        }
        .products {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
        }
        .product {
            background: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .product img {
            max-width: 100%;
            max-height: 200px;
            object-fit: cover;
            border-radius: 10px;
        }
        .product h3 {
            font-size: 18px;
            margin: 10px 0 5px;
        }
        .product p {
            font-size: 16px;
            color: #6a11cb;
        }
    </style>
</head>
<body>

<header>
    <h1>hergunpazar.com</h1>
    <p>Kategori Sayfası</p>
</header>

<div class="container">
    <?php if (isset($categories[$catKey])): ?>
        <h2><?php echo $categories[$catKey]['title']; ?> Ürünleri</h2>

        <div class="subcategories">
            <?php foreach ($categories[$catKey]['subs'] as $sub): ?>
                <a href="?cat=<?php echo $catKey; ?>&sub=<?php echo $sub; ?>"
                   <?php echo $subKey === $sub ? 'style="font-weight:bold;"' : ''; ?>>
                   <?php echo ucwords(str_replace('-', ' ', $sub)); ?>
                </a>
            <?php endforeach; ?>
        </div>

        <div class="products">
            <?php
            try {
                $query = "SELECT * FROM products WHERE category = :cat";
                $params = ['cat' => $catKey];

                if (!empty($subKey)) {
                    $query .= " AND subcategory = :sub";
                    $params['sub'] = $subKey;
                }

                $stmt = $db->prepare($query);
                $stmt->execute($params);
                $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

                if ($products):
                    foreach ($products as $product):
            ?>
                <div class="product">
                    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="">
                    <h3><?php echo htmlspecialchars($product['title']); ?></h3>
                    <p><?php echo number_format($product['price'], 2); ?> TL</p>
                </div>
            <?php
                    endforeach;
                else:
                    echo "<p>Bu kategoriye ait ürün bulunamadı.</p>";
                endif;
            } catch (PDOException $e) {
                echo "<p>Hata: " . $e->getMessage() . "</p>";
            }
            ?>
        </div>
    <?php else: ?>
        <p>Geçersiz kategori.</p>
    <?php endif; ?>
</div>

<footer>
    <p>&copy; <?php echo date("Y"); ?> hergunpazar.com</p>
</footer>

</body>
</html>
