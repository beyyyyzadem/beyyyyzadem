<?php
session_start();
require_once "config/db.php"; // Veritabanı bağlantısı

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (!empty($email) && !empty($password)) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                // Giriş başarılı
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_email'] = $user['email'];
                header("Location: index.php");
                exit();
            } else {
                $message = "Hatalı şifre.";
            }
        } else {
            $message = "Kullanıcı bulunamadı.";
        }
    } else {
        $message = "Lütfen tüm alanları doldurun.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Giriş Yap</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Giriş Yap</h2>
    <?php if (!empty($message)) echo "<p style='color:red;'>$message</p>"; ?>

    <form action="login.php" method="POST">
        <label for="email">E-posta:</label><br>
        <input type="email" name="email" required><br><br>

        <label for="password">Şifre:</label><br>
        <input type="password" name="password" required><br><br>

        <button type="submit">Giriş Yap</button>
    </form>
</div>

</body>
</html>
