<?php
// Geçici çözüm: Hassas bilgileri direk yaz
$db_host = "localhost";
$db_name = "herguswp_hergunpazar_db";
$db_user = "herguswp_beyyyyzadem";
$db_pass = "223145223145M.m"; // 

try {
    $pdo = new PDO(
        "mysql:host=$db_host;dbname=$db_name;charset=utf8mb4",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("Veritabanı bağlantı hatası!");
}