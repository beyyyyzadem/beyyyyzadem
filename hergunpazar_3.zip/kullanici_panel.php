<?php
session_start();
require_once "config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Kullanıcı bilgilerini çek
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($name, $email);
$stmt->fetch();
$stmt->close();

// Güncelleme işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_name = trim($_POST['name']);
    $new_email = trim($_POST['email']);
    $new_password = trim($_POST['password']);

    if (!empty($new_name) && !empty($new_email)) {
        // Şifre girilmişse güncelle
        if (!empty($new_password)) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET name=?, email=?, password=? WHERE id=?");
            $stmt->bind_param("sssi", $new_name, $new_email, $hashed_password, $user_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
            $stmt->bind_param("ssi", $new_name, $new_email, $user_id);
        }

        if ($stmt->execute()) {
            $_SESSION['user_name'] = $new_name;
            $_SESSION['user_email'] = $new_email;
            $message = "Bilgiler başarıyla güncellendi.";
        } else {
            $message = "Hata oluştu. Lütfen tekrar deneyin.";
        }
        $stmt->close();
    } else {
        $message = "Ad ve e-posta boş bırakılamaz.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kullanıcı Paneli</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Kullanıcı Paneli</h2>
    <?php if (!empty($message)) echo "<p style='color: green;'>$message</p>"; ?>

    <form method="post" action="">
        <label>Adınız Soyadınız:</label><br>
        <input type="text" name="name" value="<?php echo htmlspecialchars($name); ?>" required><br><br>

        <label>E-Posta:</label><br>
        <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required><br><br>

        <label>Yeni Şifre (boş bırakılırsa değişmez):</label><br>
        <input type="password" name="password"><br><br>

        <button type="submit">Güncelle</button>
    </form>

    <hr>

    <h3>Adreslerim</h3>
    <p><a href="adreslerim.php">Adres bilgilerinizi görüntülemek veya düzenlemek için tıklayın</a></p>

    <h3>Kart Bilgilerim</h3>
    <p><a href="kartlarim.php">Kayıtlı kartlarınızı yönetmek için tıklayın</a></p>
</div>

</body>
</html>
