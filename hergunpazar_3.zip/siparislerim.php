<?php
session_start();
require_once "config/db.php";

if (!isset($_SESSION['kullanici_id'])) {
    header("Location: giris.php");
    exit();
}

$kullanici_id = $_SESSION['kullanici_id'];

// Kullanıcının siparişlerini çek
$sorgu = $conn->prepare("SELECT * FROM siparisler WHERE kullanici_id = ? ORDER BY tarih DESC");
$sorgu->bind_param("i", $kullanici_id);
$sorgu->execute();
$siparisler = $sorgu->get_result();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Siparişlerim</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Siparişlerim</h2>

    <?php if ($siparisler->num_rows > 0): ?>
        <table border="1" cellpadding="6">
            <tr>
                <th>Sipariş No</th>
                <th>Tarih</th>
                <th>Tutar</th>
                <th>Durum</th>
                <th>Detay</th>
            </tr>
            <?php while ($siparis = $siparisler->fetch_assoc()): ?>
                <tr>
                    <td>#<?= $siparis['id'] ?></td>
                    <td><?= date("d.m.Y H:i", strtotime($siparis['tarih'])) ?></td>
                    <td><?= number_format($siparis['toplam_tutar'], 2) ?> ₺</td>
                    <td><?= htmlspecialchars($siparis['durum']) ?></td>
                    <td><a href="siparis_detay.php?id=<?= $siparis['id'] ?>">Görüntüle</a></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Henüz bir siparişiniz bulunmamaktadır.</p>
