<?php
session_start();

if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['user_name'] = $_POST['name'];
    // Not: Gerçek sistemde veritabanına da yazılır
    header("Location: profile.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Bilgileri Düzenle</title>
</head>
<body>
<?php include 'header.php'; ?>

<h2 style="padding: 20px;">Bilgileri Düzenle</h2>

<form method="POST" style="padding: 20px;">
    <label>Ad Soyad:</label><br>
    <input type="text" name="name" value="<?php echo htmlspecialchars($_SESSION['user_name']); ?>" required><br><br>

    <button type="submit">Kaydet</button>
</form>

</body>
</html>
