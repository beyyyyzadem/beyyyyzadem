<?php
session_start();
require_once "config/db.php";

if (!isset($_SESSION['kullanici_id'])) {
    header("Location: giris.php");
    exit();
}

if (!isset($_GET['id'])) {
    echo "Sipariş ID belirtilmedi.";
    exit();
}

$siparis_id = intval($_GET['id']);
$kullanici_id = $_SESSION['kullanici_id'];

// Siparişin gerçekten bu kullanıcıya ait olup olmadığını kontrol et
$sorgu = $conn->prepare("SELECT * FROM siparisler WHERE id = ? AND kullanici_id = ?");
$sorgu->bind_param("ii", $siparis_id, $kullanici_id);
$sorgu->execute();
$siparis = $sorgu->get_result()->fetch_assoc();

if (!$siparis) {
    echo "Sipariş bulunamadı veya yetkiniz yok.";
    exit();
}

// Sipariş ürünlerini al
$urunSorgu = $conn->prepare("
    SELECT su.*, u.ad AS urun_adi, u.resim, u.fiyat 
    FROM siparis_urunleri su 
    JOIN urunler u ON su.urun_id = u.id 
    WHERE su.siparis_id = ?
");
$urunSorgu->bind_param("i", $siparis_id);
$urunSorgu->execute();
$urunler = $urunSorgu->get_result();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sipariş Detayı</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Sipariş Detayı (#<?= $siparis_id ?>)</h2>
    <p><strong>Sipariş Tarihi:</strong> <?= date("d.m.Y H:i", strtotime($siparis['tarih'])) ?></p>
    <p><strong>Durum:</strong> <?= htmlspecialchars($siparis['durum']) ?></p>
    <p><strong>Toplam Tutar:</strong> <?= number_format($siparis['toplam_tutar'], 2) ?> ₺</p>

    <h3>Ürünler:</h3>
    <?php if ($urunler->num_rows > 0): ?>
        <table border="1" cellpadding="6">
            <tr>
                <th>Görsel</th>
                <th>Ürün Adı</th>
                <th>Adet</th>
                <th>Birim Fiyat</th>
                <th>Ara Toplam</th>
            </tr>
            <?php while ($urun = $urunler->fetch_assoc()): ?>
                <tr>
                    <td><img src="assets/img/urunler/<?= $urun['resim'] ?>" alt="<?= $urun['urun_adi'] ?>" width="50"></td>
                    <td><?= htmlspecialchars($urun['urun_adi']) ?></td>
                    <td><?= $urun['adet'] ?></td>
                    <td><?= number_format($urun['fiyat'], 2) ?> ₺</td>
                    <td><?= number_format($urun['fiyat'] * $urun['adet'], 2) ?> ₺</td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Bu siparişte ürün bilgisi bulunamadı.</p>
    <?php endif; ?>
</div>

</body>
</html>
