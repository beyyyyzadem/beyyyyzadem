<?php
session_start();
require_once "config/db.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Adres silme
if (isset($_GET['sil'])) {
    $id = (int)$_GET['sil'];
    $stmt = $conn->prepare("DELETE FROM adresler WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $stmt->close();
    $message = "Adres silindi.";
}

// Adres ekleme / güncelleme
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $baslik = trim($_POST['baslik']);
    $adres = trim($_POST['adres']);

    if (!empty($baslik) && !empty($adres)) {
        if (!empty($_POST['adres_id'])) {
            // Güncelle
            $adres_id = (int)$_POST['adres_id'];
            $stmt = $conn->prepare("UPDATE adresler SET baslik=?, adres=? WHERE id=? AND user_id=?");
            $stmt->bind_param("ssii", $baslik, $adres, $adres_id, $user_id);
            $stmt->execute();
            $stmt->close();
            $message = "Adres güncellendi.";
        } else {
            // Yeni adres ekle
            $stmt = $conn->prepare("INSERT INTO adresler (user_id, baslik, adres) VALUES (?, ?, ?)");
            $stmt->bind_param("iss", $user_id, $baslik, $adres);
            $stmt->execute();
            $stmt->close();
            $message = "Adres eklendi.";
        }
    }
}

// Tek adres çek (düzenleme için)
$duzenle_adres = null;
if (isset($_GET['duzenle'])) {
    $id = (int)$_GET['duzenle'];
    $stmt = $conn->prepare("SELECT id, baslik, adres FROM adresler WHERE id=? AND user_id=?");
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $stmt->bind_result($aid, $abaslik, $aadres);
    if ($stmt->fetch()) {
        $duzenle_adres = ['id' => $aid, 'baslik' => $abaslik, 'adres' => $aadres];
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Adreslerim</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Adreslerim</h2>
    <?php if (!empty($message)) echo "<p style='color:green;'>$message</p>"; ?>

    <table border="1" cellpadding="10" cellspacing="0">
        <tr>
            <th>Başlık</th>
            <th>Adres</th>
            <th>İşlem</th>
        </tr>
        <?php
        $stmt = $conn->prepare("SELECT id, baslik, adres FROM adresler WHERE user_id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $stmt->bind_result($id, $baslik, $adres);
        while ($stmt->fetch()) {
            echo "<tr>
                    <td>" . htmlspecialchars($baslik) . "</td>
                    <td>" . nl2br(htmlspecialchars($adres)) . "</td>
                    <td>
                        <a href='adreslerim.php?duzenle=$id'>Düzenle</a> | 
                        <a href='adreslerim.php?sil=$id' onclick='return confirm(\"Silmek istediğinize emin misiniz?\")'>Sil</a>
                    </td>
                  </tr>";
        }
        $stmt->close();
        ?>
    </table>

    <hr>
    <h3><?php echo $duzenle_adres ? "Adres Güncelle" : "Yeni Adres Ekle"; ?></h3>
    <form method="post" action="">
        <input type="hidden" name="adres_id" value="<?php echo $duzenle_adres['id'] ?? ''; ?>">
        <label>Adres Başlığı:</label><br>
        <input type="text" name="baslik" value="<?php echo $duzenle_adres['baslik'] ?? ''; ?>" required><br><br>

        <label>Adres:</label><br>
        <textarea name="adres" rows="4" cols="50" required><?php echo $duzenle_adres['adres'] ?? ''; ?></textarea><br><br>

        <button type="submit"><?php echo $duzenle_adres ? "Güncelle" : "Ekle"; ?></button>
    </form>
</div>

</body>
</html>
