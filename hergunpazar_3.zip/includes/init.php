<?php
// Session'ı güvenli şekilde başlat
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Veritabanı bağlantısını dahil et
require_once __DIR__ . '/database.php';

// Global sabitler (isteğe bağlı)
define('SITE_NAME', 'Hergün Pazar');
define('BASE_URL', 'http://localhost'); // Canlıda https://www.hergunpazar.com olabilir
