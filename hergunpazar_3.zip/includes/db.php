<?php
$host = "localhost";
$user = "herguswp_beyyyyzadem";
$pass = "223145223145M.m";
$dbname = "herguswp_hergunpazar_db";

try {
    $db = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Veritabanı bağlantı hatası: " . $e->getMessage());
}
?>
