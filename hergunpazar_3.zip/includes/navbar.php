<div class="user-actions">
  <?php if($userLoggedIn): ?>
    <!-- Kullanıcı giriş yaptıysa açılır menü ve diğer aksiyonlar -->
    <div class="user-dropdown">
      <div class="user-profile">
        <img src="<?= $_SESSION['user']['avatar'] ?? 'images/default-avatar.jpg' ?>" class="user-avatar" alt="Profil">
        <span class="user-name"><?= $_SESSION['user']['name'] ?></span>
        <i class="fas fa-chevron-down user-dropdown-arrow"></i>
      </div>
      <div class="dropdown-menu">
        <div class="dropdown-header">
          <div class="dropdown-user">
            <img src="<?= $_SESSION['user']['avatar'] ?? 'images/default-avatar.jpg' ?>" class="dropdown-user-avatar" alt="Profil">
            <div class="dropdown-user-info">
              <div class="dropdown-user-name"><?= $_SESSION['user']['name'] ?></div>
              <div class="dropdown-user-email"><?= $_SESSION['user']['email'] ?></div>
            </div>
          </div>
        </div>
        <a href="profile.php" class="dropdown-item">
          <i class="fas fa-user"></i>
          <span>Profilim</span>
        </a>
        <a href="orders.php" class="dropdown-item">
          <i class="fas fa-box"></i>
          <span>Siparişlerim</span>
        </a>
        <a href="wishlist.php" class="dropdown-item">
          <i class="far fa-heart"></i>
          <span>Favorilerim</span>
          <?php if($wishlistCount > 0): ?>
            <span style="margin-left: auto; font-size: 12px; color: var(--primary);"><?= $wishlistCount ?></span>
          <?php endif; ?>
        </a>
        <div class="dropdown-divider"></div>
        <a href="coupons.php" class="dropdown-item">
          <i class="fas fa-tag"></i>
          <span>Kuponlarım</span>
          <span style="margin-left: auto; font-size: 12px; color: var(--success);">3 Yeni</span>
        </a>
        <a href="messages.php" class="dropdown-item">
          <i class="fas fa-envelope"></i>
          <span>Mesajlarım</span>
          <span style="margin-left: auto; font-size: 12px; color: var(--danger);">2 Okunmamış</span>
        </a>
        <div class="dropdown-divider"></div>
        <a href="settings.php" class="dropdown-item">
          <i class="fas fa-cog"></i>
          <span>Hesap Ayarları</span>
        </a>
        <a href="logout.php" class="dropdown-item">
          <i class="fas fa-sign-out-alt"></i>
          <span>Çıkış Yap</span>
        </a>
      </div>
    </div>
  <?php else: ?>
    <!-- Giriş Yap ve Kayıt Ol Butonları -->
    <a href="login.php" class="action-item">
      <i class="far fa-user action-icon"></i>
      <span class="action-label">Giriş Yap</span>
    </a>
    <a href="register.php" class="action-item">
      <i class="fas fa-user-plus action-icon"></i>
      <span class="action-label">Kayıt Ol</span>
    </a>
  <?php endif; ?>

  <!-- Favoriler -->
  <a href="wishlist.php" class="action-item">
    <i class="far fa-heart action-icon"></i>
    <span class="action-label">Favoriler</span>
    <?php if($wishlistCount > 0): ?>
      <span class="action-badge"><?= $wishlistCount ?></span>
    <?php endif; ?>
  </a>

  <!-- Sepet -->
  <a href="cart.php" class="action-item">
    <i class="fas fa-shopping-bag action-icon"></i>
    <span class="action-label">Sepetim</span>
    <?php if($cartCount > 0): ?>
      <span class="action-badge"><?= $cartCount ?></span>
    <?php endif; ?>
  </a>
</div>