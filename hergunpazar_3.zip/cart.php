<?php
session_start();
$cart = isset($_SESSION['cart']) ? $_SESSION['cart'] : [];
$total = 0;
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sepetim</title>
</head>
<body>
<?php include 'header.php'; ?>

<h2 style="padding: 20px;">Sepetim</h2>

<?php if (empty($cart)): ?>
    <p style="padding: 20px;">Sepetiniz boş.</p>
<?php else: ?>
    <table border="1" cellpadding="10" style="margin: 20px;">
        <tr>
            <th>Ürün Adı</th>
            <th>Fiyat</th>
            <th>İşlem</th>
        </tr>
        <?php foreach ($cart as $item): ?>
            <tr>
                <td><?php echo htmlspecialchars($item['name']); ?></td>
                <td><?php echo $item['price']; ?> TL</td>
                <td><a href="cart_remove.php?id=<?php echo $item['id']; ?>">Kaldır</a></td>
            </tr>
            <?php $total += $item['price']; ?>
        <?php endforeach; ?>
        <tr>
            <td colspan="2"><strong>Toplam</strong></td>
            <td><strong><?php echo $total; ?> TL</strong></td>
        </tr>
    </table>
<?php endif; ?>
</body>
</html>
