<?php
session_start();
require_once "config/db.php";

if (!isset($_SESSION['kullanici_id'])) {
    header("Location: giris.php");
    exit();
}

$kullanici_id = $_SESSION['kullanici_id'];

// Adres silme
if (isset($_GET['sil'])) {
    $adres_id = intval($_GET['sil']);
    $stmt = $conn->prepare("DELETE FROM adresler WHERE id = ? AND kullanici_id = ?");
    $stmt->bind_param("ii", $adres_id, $kullanici_id);
    $stmt->execute();
    $stmt->close();
    header("Location: adres_duzenle.php");
    exit();
}

// Yeni adres ekleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['ekle'])) {
    $baslik = $_POST['baslik'];
    $adres_metni = $_POST['adres_metni'];
    $il = $_POST['il'];
    $ilce = $_POST['ilce'];
    $posta_kodu = $_POST['posta_kodu'];

    $stmt = $conn->prepare("INSERT INTO adresler (kullanici_id, baslik, adres_metni, il, ilce, posta_kodu) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $kullanici_id, $baslik, $adres_metni, $il, $ilce, $posta_kodu);
    $stmt->execute();
    $stmt->close();
    header("Location: adres_duzenle.php");
    exit();
}

// Adresleri çek
$stmt = $conn->prepare("SELECT id, baslik, adres_metni, il, ilce, posta_kodu FROM adresler WHERE kullanici_id = ?");
$stmt->bind_param("i", $kullanici_id);
$stmt->execute();
$adresler = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Adreslerim</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Adreslerim</h2>

    <table border="1" cellpadding="5">
        <tr>
            <th>Başlık</th>
            <th>Adres</th>
            <th>İl / İlçe</th>
            <th>Posta Kodu</th>
            <th>İşlem</th>
        </tr>
        <?php while ($row = $adresler->fetch_assoc()) : ?>
            <tr>
                <td><?= htmlspecialchars($row['baslik']) ?></td>
                <td><?= nl2br(htmlspecialchars($row['adres_metni'])) ?></td>
                <td><?= htmlspecialchars($row['il']) . ' / ' . htmlspecialchars($row['ilce']) ?></td>
                <td><?= htmlspecialchars($row['posta_kodu']) ?></td>
                <td>
                    <a href="?sil=<?= $row['id'] ?>" onclick="return confirm('Adresi silmek istediğinize emin misiniz?')">Sil</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <h3>Yeni Adres Ekle</h3>
    <form method="post">
        <label>Adres Başlığı:</label><br>
        <input type="text" name="baslik" required><br>

        <label>Adres:</label><br>
        <textarea name="adres_metni" rows="3" required></textarea><br>

        <label>İl:</label><br>
        <input type="text" name="il" required><br>

        <label>İlçe:</label><br>
        <input type="text" name="ilce" required><br>

        <label>Posta Kodu:</label><br>
        <input type="text" name="posta_kodu" required><br>

        <button type="submit" name="ekle">Ekle</button>
    </form>
</div>

</body>
</html>
