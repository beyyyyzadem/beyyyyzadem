<?php
session_start();
require_once "config/db.php";

if (!isset($_SESSION['kullanici_id'])) {
    header("Location: giris.php");
    exit();
}

$kullanici_id = $_SESSION['kullanici_id'];

// Kart silme
if (isset($_GET['sil'])) {
    $kart_id = intval($_GET['sil']);
    $stmt = $conn->prepare("DELETE FROM kartlar WHERE id = ? AND kullanici_id = ?");
    $stmt->bind_param("ii", $kart_id, $kullanici_id);
    $stmt->execute();
    $stmt->close();
    header("Location: kart_bilgileri.php");
    exit();
}

// Yeni kart ekleme
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['ekle'])) {
    $kart_sahibi = $_POST['kart_sahibi'];
    $kart_numarasi = $_POST['kart_numarasi'];
    $son_kullanma = $_POST['son_kullanma'];
    $cvv = $_POST['cvv'];

    $son_dort_hane = substr(preg_replace('/\D/', '', $kart_numarasi), -4);

    $stmt = $conn->prepare("INSERT INTO kartlar (kullanici_id, kart_sahibi, son_dort_hane, son_kullanma, cvv) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $kullanici_id, $kart_sahibi, $son_dort_hane, $son_kullanma, $cvv);
    $stmt->execute();
    $stmt->close();
    header("Location: kart_bilgileri.php");
    exit();
}

// Kartları çek
$stmt = $conn->prepare("SELECT id, kart_sahibi, son_dort_hane, son_kullanma FROM kartlar WHERE kullanici_id = ?");
$stmt->bind_param("i", $kullanici_id);
$stmt->execute();
$kartlar = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kart Bilgilerim</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Kart Bilgilerim</h2>

    <table border="1" cellpadding="5">
        <tr>
            <th>Kart Sahibi</th>
            <th>Kart Numarası</th>
            <th>Son Kullanma</th>
            <th>İşlem</th>
        </tr>
        <?php while ($row = $kartlar->fetch_assoc()) : ?>
            <tr>
                <td><?= htmlspecialchars($row['kart_sahibi']) ?></td>
                <td>**** **** **** <?= htmlspecialchars($row['son_dort_hane']) ?></td>
                <td><?= htmlspecialchars($row['son_kullanma']) ?></td>
                <td><a href="?sil=<?= $row['id'] ?>" onclick="return confirm('Bu kartı silmek istiyor musunuz?')">Sil</a></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <h3>Yeni Kart Ekle</h3>
    <form method="post">
        <label>Kart Sahibi:</label><br>
        <input type="text" name="kart_sahibi" required><br>

        <label>Kart Numarası:</label><br>
        <input type="text" name="kart_numarasi" required><br>

        <label>Son Kullanma Tarihi (AA/YY):</label><br>
        <input type="text" name="son_kullanma" required><br>

        <label>CVV:</label><br>
        <input type="text" name="cvv" required><br>

        <button type="submit" name="ekle">Ekle</button>
    </form>
</div>

</body>
</html>
