<?php
session_start();
require_once "config/db.php";

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Geçersiz ürün.";
    exit();
}

$urun_id = (int)$_GET['id'];

// Ürün bilgisi
$stmt = $conn->prepare("SELECT id, baslik, aciklama, fiyat, resim, kategori_id FROM urunler WHERE id = ?");
$stmt->bind_param("i", $urun_id);
$stmt->execute();
$stmt->bind_result($id, $baslik, $aciklama, $fiyat, $resim, $kategori_id);
if (!$stmt->fetch()) {
    echo "Ürün bulunamadı.";
    exit();
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title><?php echo htmlspecialchars($baslik); ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <div style="display:flex; gap:40px;">
        <div style="flex:1;">
            <img src="assets/img/urunler/<?php echo htmlspecialchars($resim); ?>" width="100%" alt="<?php echo htmlspecialchars($baslik); ?>">
        </div>
        <div style="flex:1;">
            <h1><?php echo htmlspecialchars($baslik); ?></h1>
            <p><?php echo nl2br(htmlspecialchars($aciklama)); ?></p>
            <p><strong>Fiyat: </strong><?php echo number_format($fiyat, 2); ?> TL</p>
            <form method="post" action="sepet.php">
                <input type="hidden" name="urun_id" value="<?php echo $id; ?>">
                <label>Adet: </label>
                <input type="number" name="adet" value="1" min="1">
                <button type="submit">Sepete Ekle</button>
            </form>
        </div>
    </div>

    <hr>
    <h3>Benzer Ürünler</h3>
    <div style="display:flex; gap:20px; flex-wrap:wrap;">
        <?php
        $stmt = $conn->prepare("SELECT id, baslik, resim, fiyat FROM urunler WHERE kategori_id = ? AND id != ? ORDER BY RAND() LIMIT 4");
        $stmt->bind_param("ii", $kategori_id, $urun_id);
        $stmt->execute();
        $stmt->bind_result($oid, $obaslik, $oresim, $ofiyat);
        while ($stmt->fetch()) {
            echo "<div style='width: 23%; border: 1px solid #ddd; padding:10px;'>
                    <a href='urun_detay.php?id=$oid'>
                        <img src='assets/img/urunler/$oresim' width='100%' alt='".htmlspecialchars($obaslik)."'>
                        <h4>".htmlspecialchars($obaslik)."</h4>
                        <p><strong>".number_format($ofiyat,2)." TL</strong></p>
                    </a>
                  </div>";
        }
        $stmt->close();
        ?>
    </div>
</div>

</body>
</html>
