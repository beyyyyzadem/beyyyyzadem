<?php
session_start();

if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit;
}

// Sahte kart bilgileri (demo)
$card_number = "**** **** **** 1234";
$card_holder = $_SESSION['user_name'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card_number = $_POST['card_number'];
    $card_holder = $_POST['card_holder'];
    // Gerçek sistemde veritabanına kaydedilir
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kart Bilgileri</title>
</head>
<body>
<?php include 'header.php'; ?>

<h2 style="padding: 20px;">Kart Bilgilerim</h2>

<form method="POST" style="padding: 20px;">
    <label>Kart Numarası:</label><br>
    <input type="text" name="card_number" value="<?php echo htmlspecialchars($card_number); ?>"><br><br>

    <label>Kart Sahibi:</label><br>
    <input type="text" name="card_holder" value="<?php echo htmlspecialchars($card_holder); ?>"><br><br>

    <button type="submit">Kaydet</button>
</form>

</body>
</html>
