<?php
include 'auth.php';
require_once '../config/database.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Geçersiz ürün ID");
}

$product_id = $_GET['id'];
$seller_id = $_SESSION['user_id'];

// Ürünün satıcıya ait olup olmadığını kontrol et
$stmt = $conn->prepare("SELECT image FROM products WHERE id = ? AND seller_id = ?");
$stmt->execute([$product_id, $seller_id]);
$product = $stmt->fetch();

if (!$product) {
    die("Ürün bulunamadı veya size ait değil");
}

// Eski görseli sil
if (!empty($product['image']) && file_exists('../' . $product['image'])) {
    unlink('../' . $product['image']);
}

// Ürünü sil
$stmt = $conn->prepare("DELETE FROM products WHERE id = ? AND seller_id = ?");
$stmt->execute([$product_id, $seller_id]);

// Listeye yönlendir
header("Location: product_list.php?deleted=1");
exit;
?>
