<?php include 'auth.php'; ?>
<?php header('Location: dashboard.php'); exit; ?>
<?php include('includes/navbar.php'); ?>
