<?php
include 'auth.php';
require_once '../config/database.php';

$seller_id = $_SESSION['user_id'];

// Satıcıya ait bildirimleri getir
$stmt = $conn->prepare("
    SELECT * FROM notifications 
    WHERE user_id = ? AND user_type = 'seller'
    ORDER BY created_at DESC
");
$stmt->execute([$seller_id]);
$notifications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Bildirimler</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 20px; }
        .box {
            max-width: 700px; margin: auto; background: #fff;
            padding: 20px; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h2 { text-align: center; color: #333; }
        .notification {
            padding: 12px; border-bottom: 1px solid #ddd;
        }
        .notification:last-child { border-bottom: none; }
        .date {
            font-size: 12px; color: #888;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>🔔 Bildirimler</h2>

    <?php if (empty($notifications)): ?>
        <p>Hiç bildiriminiz yok.</p>
    <?php else: ?>
        <?php foreach ($notifications as $n): ?>
            <div class="notification">
                <strong><?= htmlspecialchars($n['title']) ?></strong><br>
                <span><?= htmlspecialchars($n['message']) ?></span><br>
                <span class="date"><?= $n['created_at'] ?></span>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</body>
</html>
