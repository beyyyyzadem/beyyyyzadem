<?php
session_start();

if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit;
}

// Sahte adres (örnek)
$address = "İstanbul, Türkiye";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $address = $_POST['address'];
    // Gerçek sistemde veritabanına kaydedilir
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Adres Bilgileri</title>
</head>
<body>
<?php include 'header.php'; ?>

<h2 style="padding: 20px;">Adres Bilgilerim</h2>

<form method="POST" style="padding: 20px;">
    <textarea name="address" rows="4" cols="50"><?php echo htmlspecialchars($address); ?></textarea><br><br>
    <button type="submit">Kaydet</button>
</form>

</body>
</html>
