<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Her Gün Pazar</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .user-menu {
            position: relative;
            display: inline-block;
        }
        .user-dropdown {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            border: 1px solid #ddd;
            min-width: 160px;
            z-index: 99;
        }
        .user-dropdown a {
            display: block;
            padding: 10px;
            color: black;
            text-decoration: none;
        }
        .user-dropdown a:hover {
            background-color: #f0f0f0;
        }
        .user-menu:hover .user-dropdown {
            display: block;
        }
    </style>
</head>
<body>

<header>
    <div class="navbar">
        <a href="index.php">Anasayfa</a>
        <a href="urunler.php">Ürünler</a>
        <a href="iletisim.php">İletişim</a>

        <div style="float:right;">
            <?php if (isset($_SESSION['user_name'])): ?>
                <div class="user-menu">
                    <span>👤 <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                    <div class="user-dropdown">
                        <a href="kullanici_panel.php">Profilim</a>
                        <a href="siparislerim.php">Siparişlerim</a>
                        <a href="logout.php">Çıkış Yap</a>
                    </div>
                </div>
            <?php else: ?>
                <div class="user-menu">
                    <span>👤 Giriş Yap</span>
                    <div class="user-dropdown">
                        <a href="login.php">Giriş Yap</a>
                        <a href="register.php">Üye Ol</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</header>

