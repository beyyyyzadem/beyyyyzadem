<?php
session_start();
require_once "config/db.php";

if (!isset($_SESSION['kullanici_id'])) {
    header("Location: giris.php");
    exit();
}

$kullanici_id = $_SESSION['kullanici_id'];

// Adresleri al
$adres_sorgu = $conn->prepare("SELECT * FROM adresler WHERE kullanici_id = ?");
$adres_sorgu->bind_param("i", $kullanici_id);
$adres_sorgu->execute();
$adresler = $adres_sorgu->get_result();

// Kartları al
$kart_sorgu = $conn->prepare("SELECT * FROM kartlar WHERE kullanici_id = ?");
$kart_sorgu->bind_param("i", $kullanici_id);
$kart_sorgu->execute();
$kartlar = $kart_sorgu->get_result();

// Sepeti kontrol et
$sepet = isset($_SESSION['sepet']) ? $_SESSION['sepet'] : [];

if (empty($sepet)) {
    echo "<p>Sepetiniz boş.</p>";
    exit();
}

// Siparişi tamamlama
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $adres_id = $_POST['adres_id'];
    $kart_id = $_POST['kart_id'];
    $toplam_tutar = 0;

    foreach ($sepet as $urun) {
        $toplam_tutar += $urun['adet'] * $urun['fiyat'];
    }

    // Siparişi kaydet
    $stmt = $conn->prepare("INSERT INTO siparisler (kullanici_id, adres_id, kart_id, toplam_tutar, durum, tarih) VALUES (?, ?, ?, ?, 'Hazırlanıyor', NOW())");
    $stmt->bind_param("iiid", $kullanici_id, $adres_id, $kart_id, $toplam_tutar);
    $stmt->execute();
    $siparis_id = $stmt->insert_id;
    $stmt->close();

    // Sipariş detaylarını kaydet
    $detay_sorgu = $conn->prepare("INSERT INTO siparis_detay (siparis_id, urun_id, adet, fiyat) VALUES (?, ?, ?, ?)");

    foreach ($sepet as $urun) {
        $detay_sorgu->bind_param("iiid", $siparis_id, $urun['urun_id'], $urun['adet'], $urun['fiyat']);
        $detay_sorgu->execute();
    }

    $detay_sorgu->close();

    // Sepeti temizle
    unset($_SESSION['sepet']);

    header("Location: siparislerim.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sipariş Tamamlama</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <h2>Siparişi Tamamla</h2>

    <h3>Sepetiniz</h3>
    <table border="1" cellpadding="5">
        <tr>
            <th>Ürün</th>
            <th>Adet</th>
            <th>Birim Fiyat</th>
            <th>Ara Toplam</th>
        </tr>
        <?php
        $toplam = 0;
        foreach ($sepet as $urun) :
            $ara_toplam = $urun['adet'] * $urun['fiyat'];
            $toplam += $ara_toplam;
        ?>
        <tr>
            <td><?= htmlspecialchars($urun['ad']) ?></td>
            <td><?= $urun['adet'] ?></td>
            <td><?= number_format($urun['fiyat'], 2) ?> ₺</td>
            <td><?= number_format($ara_toplam, 2) ?> ₺</td>
        </tr>
        <?php endforeach; ?>
        <tr>
            <td colspan="3"><strong>Toplam:</strong></td>
            <td><strong><?= number_format($toplam, 2) ?> ₺</strong></td>
        </tr>
    </table>

    <form method="post">
        <h3>Adres Seçimi</h3>
        <select name="adres_id" required>
            <?php while ($adres = $adresler->fetch_assoc()) : ?>
                <option value="<?= $adres['id'] ?>"><?= htmlspecialchars($adres['adres_baslik']) ?> - <?= htmlspecialchars($adres['adres']) ?></option>
            <?php endwhile; ?>
        </select>

        <h3>Kart Seçimi</h3>
        <select name="kart_id" required>
            <?php while ($kart = $kartlar->fetch_assoc()) : ?>
                <option value="<?= $kart['id'] ?>"><?= htmlspecialchars($kart['kart_sahibi']) ?> - ****<?= $kart['son_dort_hane'] ?></option>
            <?php endwhile; ?>
        </select>

        <br><br>
        <button type="submit">Siparişi Tamamla</button>
    </form>
</div>

</body>
</html>
