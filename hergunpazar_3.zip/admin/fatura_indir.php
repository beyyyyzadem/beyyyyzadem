<?php
require_once '../includes/admin_auth.php';
require_once '../core/database.php';

use Dompdf\Dompdf;
require '../vendor/autoload.php';

if (!isset($_GET['id'])) {
    die('Sipariş ID belirtilmedi.');
}

$order_id = intval($_GET['id']);
$conn = require '../core/database.php';

// Siparişi çek
$stmt = $conn->prepare("SELECT o.*, u.name, u.email FROM orders o JOIN users u ON o.user_id = u.id WHERE o.id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) die('Sipariş bulunamadı.');

// Ürünleri çek
$stmt = $conn->prepare("SELECT oi.*, p.name AS product_name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?");
$stmt->execute([$order_id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);

// HTML fatura şablonu
ob_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; }
        h1 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { border: 1px solid #aaa; padding: 8px; text-align: left; }
    </style>
</head>
<body>
    <h1>FATURA</h1>
    <p><strong>Fatura No:</strong> #<?= $order['id'] ?></p>
    <p><strong>Tarih:</strong> <?= date('Y-m-d', strtotime($order['created_at'])) ?></p>
    <p><strong>Müşteri:</strong> <?= htmlspecialchars($order['name']) ?> (<?= htmlspecialchars($order['email']) ?>)</p>

    <table>
        <thead>
            <tr>
                <th>Ürün</th>
                <th>Adet</th>
                <th>Birim Fiyat</th>
                <th>Ara Toplam</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['product_name']) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td><?= number_format($item['price'], 2) ?> TL</td>
                    <td><?= number_format($item['price'] * $item['quantity'], 2) ?> TL</td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <p><strong>Toplam:</strong> <?= number_format($order['total'], 2) ?> TL</p>
</body>
</html>
<?php
$html = ob_get_clean();

$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');
$dompdf->render();

$dompdf->stream("fatura_{$order_id}.pdf", ["Attachment" => true]);
exit;
