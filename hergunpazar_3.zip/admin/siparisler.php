<?php
session_start();
require_once "../config/db.php";

// Admin girişi yapılmamışsa login sayfasına gönder
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Siparişleri çek
$sorgu = $conn->prepare("
    SELECT s.*, k.ad_soyad 
    FROM siparisler s
    JOIN kullanicilar k ON s.kullanici_id = k.id
    ORDER BY s.tarih DESC
");
$sorgu->execute();
$siparisler = $sorgu->get_result();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Siparişler</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>

<h2>Sipariş Listesi</h2>

<table border="1" cellpadding="6" cellspacing="0">
    <tr>
        <th>ID</th>
        <th>Müşteri</th>
        <th>Toplam Tutar</th>
        <th>Tarih</th>
        <th>Durum</th>
        <th>İşlem</th>
    </tr>
    <?php while ($siparis = $siparisler->fetch_assoc()): ?>
        <tr>
            <td><?= $siparis['id'] ?></td>
            <td><?= htmlspecialchars($siparis['ad_soyad']) ?></td>
            <td><?= number_format($siparis['toplam_tutar'], 2) ?> ₺</td>
            <td><?= date("d.m.Y H:i", strtotime($siparis['tarih'])) ?></td>
            <td><?= htmlspecialchars($siparis['durum']) ?></td>
            <td>
                <a href="siparis_duzenle.php?id=<?= $siparis['id'] ?>">Düzenle</a>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

</body>
</html>
