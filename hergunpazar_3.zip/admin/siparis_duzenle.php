<?php
session_start();
include '../includes/db.php';

// Admin giriş kontrolü
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_giris.php");
    exit;
}

// Sipariş ID kontrolü
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin_siparisler.php");
    exit;
}

$siparis_id = intval($_GET['id']);

// Sipariş bilgilerini çek
$stmt = $conn->prepare("SELECT * FROM siparisler WHERE id = ?");
$stmt->bind_param("i", $siparis_id);
$stmt->execute();
$result = $stmt->get_result();
$siparis = $result->fetch_assoc();

if (!$siparis) {
    header("Location: admin_siparisler.php");
    exit;
}

// Güncelleme işlemi
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $durum = $_POST['durum'];

    $update = $conn->prepare("UPDATE siparisler SET durum = ? WHERE id = ?");
    $update->bind_param("si", $durum, $siparis_id);

    if ($update->execute()) {
        header("Location: admin_siparisler.php?updated=1");
        exit;
    } else {
        echo "Hata: " . $conn->error;
    }
}

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Sipariş Düzenle</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="admin-container">
        <h1>Sipariş Düzenle</h1>
        <form method="POST">
            <label>Sipariş Durumu</label>
            <select name="durum" required>
                <option value="Hazırlanıyor" <?= ($siparis['durum'] == 'Hazırlanıyor') ? 'selected' : '' ?>>Hazırlanıyor</option>
