<?php
session_start();
include '../includes/db.php';

// Admin kontrolü
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_giris.php");
    exit;
}

// ID kontrolü
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: admin_siparisler.php");
    exit;
}

$siparis_id = intval($_GET['id']);

// Siparişi sil
$stmt = $conn->prepare("DELETE FROM siparisler WHERE id = ?");
$stmt->bind_param("i", $siparis_id);
if ($stmt->execute()) {
    header("Location: admin_siparisler.php?deleted=1");
    exit;
} else {
    echo "Hata: " . $conn->error;
}
