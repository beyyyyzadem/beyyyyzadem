<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Giriş yapılmamışsa yönlendir
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<title>Admin Paneli</title>
<style>
body { font-family: Arial, sans-serif; background: #fafafa; margin: 0; }
.header { background: #007bff; color: white; padding: 15px; }
.header a { color: white; text-decoration: none; margin-left: 20px; }
.content { padding: 20px; }
</style>
</head>
<body>
<div class="header">
    <span>👋 Hoş geldin, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
    <a href="logout.php">Çıkış Yap</a>
</div>
<div class="content">
    <h2>Admin Paneli</h2>
    <p>Buradan site yönetimini yapabilirsiniz.</p>
</div>
</body>
</html>
