<?php
session_start();
require_once "../config/db.php";

if (!isset($_SESSION['kullanici_rol']) || $_SESSION['kullanici_rol'] !== 'admin') {
    header("Location: ../index.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $siparis_id = (int)$_POST['siparis_id'];
    $durum = $_POST['durum'];

    $stmt = $conn->prepare("UPDATE siparisler SET durum = ? WHERE id = ?");
    $stmt->bind_param("si", $durum, $siparis_id);
    $stmt->execute();

    header("Location: siparisler.php");
    exit();
}
?>
