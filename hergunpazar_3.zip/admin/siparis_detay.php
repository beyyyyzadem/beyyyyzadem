<?php
require_once '../includes/init.php';
require_once 'admin_auth.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Geçersiz sipariş ID");
}

$order_id = (int) $_GET['id'];
$conn = require '../core/database.php';

// Sipariş ve kullanıcı bilgilerini çek
$stmt = $conn->prepare("SELECT o.*, u.name as user_name, u.email 
                        FROM orders o 
                        JOIN users u ON o.user_id = u.id 
                        WHERE o.id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    die("Sipariş bulunamadı.");
}

// ✅ Durum güncelleme işlemi (POST ile)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_status'])) {
    $new_status = $_POST['new_status'];

    $valid_statuses = ['Alındı', 'Hazırlanıyor', 'Kargoda', 'Teslim Edildi', 'İptal Edildi'];
    if (in_array($new_status, $valid_statuses)) {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$new_status, $order_id]);

        // Güncellenmiş durumu tekrar alalım
        $stmt = $conn->prepare("SELECT o.*, u.name as user_name, u.email 
                                FROM orders o 
                                JOIN users u ON o.user_id = u.id 
                                WHERE o.id = ?");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

// Sipariş ürünlerini çek
$stmt = $conn->prepare("SELECT oi.*, p.name, p.image 
                        FROM order_items oi 
                        JOIN products p ON oi.product_id = p.id 
                        WHERE oi.order_id = ?");
$stmt->execute([$order_id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Sipariş Detayı</title>
    <link rel="stylesheet" href="../assets/style.css">
</head>
<body>

<h1>Admin Sipariş Detayı (#<?= $order_id ?>)</h1>

<h2>Müşteri Bilgileri</h2>
<p><strong>Ad Soyad:</strong> <?= htmlspecialchars($order['user_name']) ?></p>
<p><strong>E-posta:</strong> <?= htmlspecialchars($order['email']) ?></p>

<h2>Sipariş Bilgileri</h2>
<p><strong>Durum:</strong> <?= htmlspecialchars($order['status']) ?></p>
<p><strong>Tarih:</strong> <?= htmlspecialchars($order['created_at']) ?></p>
<p><strong>Toplam:</strong> <?= number_format($order['total'], 2) ?> TL</p>

<?php if ($order['kargo_firmasi'] && $order['kargo_takip_no']): ?>
    <p><strong>Kargo:</strong> <?= htmlspecialchars($order['kargo_firmasi']) ?> - 
        <a href="https://www.google.com/search?q=<?= urlencode($order['kargo_firmasi'] . ' kargo takip') ?>" target="_blank">
            Takip No: <?= htmlspecialchars($order['kargo_takip_no']) ?>
