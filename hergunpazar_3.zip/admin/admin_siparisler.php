<?php
session_start();
include '../includes/db.php';

// Admin kontrolü
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_giris.php");
    exit;
}

// Siparişleri veritabanından çek
$sql = "SELECT s.id, s.kullanici_id, s.toplam_tutar, s.durum, s.tarih, k.ad_soyad 
        FROM siparisler s
        INNER JOIN kullanicilar k ON s.kullanici_id = k.id
        ORDER BY s.tarih DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Siparişler - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <div class="container">
        <h1>Siparişler</h1>

        <?php if (isset($_GET['updated'])): ?>
            <p class="success">Sipariş başarıyla güncellendi.</p>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Müşteri</th>
                    <th>Toplam Tutar</th>
                    <th>Durum</th>
                    <th>Tarih</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= htmlspecialchars($row['ad_soyad']) ?></td>
                        <td><?= number_format($row['toplam_tutar'], 2) ?> ₺</td>
                        <td><?= htmlspecialchars($row['durum']) ?></td>
                        <td><?= $row['tarih'] ?></td>
                        <td>
                            <a href="siparis_duzenle.php?id=<?= $row['id'] ?>" class="btn">Düzenle</a>
                            <a href="siparis_sil.php?id=<?= $row['id'] ?>" class="btn delete" onclick="return confirm('Bu siparişi silmek istediğinize emin misiniz?')">Sil</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
