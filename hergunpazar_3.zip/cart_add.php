<?php
session_start();

if (!isset($_POST['product_id'])) {
    header("Location: cart.php");
    exit;
}

$product_id = $_POST['product_id'];

// Sahte ürün bilgisi (veritabanı yerine)
$product = [
    'id' => $product_id,
    'name' => 'Sepet Ürünü ' . $product_id,
    'price' => 199.99
];

// Sepet dizisi başlat
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Sepete ekle
$_SESSION['cart'][$product_id] = $product;

// Sepet sayfasına yönlendir
header("Location: cart.php");
exit;
