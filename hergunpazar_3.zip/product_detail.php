<?php
session_start();

// Örnek mevcut ürün (normalde veritabanından gelir)
$product = [
    'id' => 1,
    'name' => 'Örnek Ürün',
    'price' => 249.99,
    'description' => 'Bu ürün çok güzel bir örnektir.',
    'image' => 'assets/images/sample.jpg',
    'category_id' => 3
];

// Örnek önerilen ürünler (aynı kategoriden 3 ürün rastgele)
$recommended_products = [
    [
        'id' => 2,
        'name' => 'Benzer Ürün 1',
        'price' => 199.99,
        'image' => 'assets/images/sample1.jpg'
    ],
    [
        'id' => 3,
        'name' => 'Benzer Ürün 2',
        'price' => 179.99,
        'image' => 'assets/images/sample2.jpg'
    ],
    [
        'id' => 4,
        'name' => 'Benzer Ürün 3',
        'price' => 229.99,
        'image' => 'assets/images/sample3.jpg'
    ]
];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title><?php echo $product['name']; ?> - Detay</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .product-container {
            display: flex;
            gap: 30px;
            padding: 20px;
        }
        .product-details {
            flex: 2;
            border: 1px solid #ccc;
            padding: 15px;
        }
        .recommended {
            flex: 1;
            border: 1px solid #ccc;
            padding: 15px;
        }
        .recommended-item {
            border-bottom: 1px solid #ddd;
            padding: 10px 0;
        }
        .recommended-item img {
            width: 100%;
            height: auto;
        }
        .recommended-item h4 {
            margin: 5px 0;
        }
        .recommended-item p {
            font-size: 14px;
        }
    </style>
</head>
<body>

<?php include 'header.php'; ?>

<div class="product-container">
    <!-- Ürün Detayları -->
    <div class="product-details">
        <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" style="width: 100%; max-width: 400px;">
        <h2><?php echo $product['name']; ?></h2>
        <p><strong>Fiyat:</strong> <?php echo $product['price']; ?> TL</p>
        <p><?php echo $product['description']; ?></p>
        <form method="POST" action="cart_add.php">
    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
    <button type="submit">Sepete Ekle</button>
</form>

    </div>

    <!-- Önerilen Ürünler -->
    <div class="recommended">
        <h3>Önerilen Ürünler</h3>
        <?php foreach ($recommended_products as $item): ?>
            <div class="recommended-item">
                <a href="product_detail.php?id=<?php echo $item['id']; ?>">
                    <img src="<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>">
                    <h4><?php echo $item['name']; ?></h4>
                    <p><?php echo $item['price']; ?> TL</p>
                </a>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>
