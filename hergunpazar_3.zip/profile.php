<?php
session_start();

// Giri� yap�lmam��sa login sayfas�na y�nlendir
if (!isset($_SESSION['user_name'])) {
    header("Location: login.php");
    exit;
}

// Sahte kullan�c� bilgileri (�rnek)
$user = [
    'name' => $_SESSION['user_name'],
    'email' => 'demo@example.com',
    'phone' => '0555 123 4567'
];
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Profil Bilgilerim</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<?php include 'header.php'; ?>

<h2 style="padding: 20px;">Merhaba <?php echo htmlspecialchars($user['name']); ?></h2>

<div style="padding: 20px;">
    <p><strong>Ad Soyad:</strong> <?php echo $user['name']; ?></p>
    <p><strong>Email:</strong> <?php echo $user['email']; ?></p>
    <p><strong>Telefon:</strong> <?php echo $user['phone']; ?></p>

    <a href="profile_edit.php">Bilgileri D�zenle</a><br>
    <a href="profile_address.php">Adres Bilgilerim</a><br>
    <a href="profile_card.php">Kart Bilgilerim</a>
</div>

</body>
</html>
