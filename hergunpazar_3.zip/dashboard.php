<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require 'core/database.php';

// GEÇİCİ USER_ID DÜZELTMESİ
if (isset($_SESSION['user']) && !isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$_SESSION['user']]);
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['user_id'] = $user['id'];
    } else {
        session_destroy();
        header("Location: index.php");
        exit;
    }
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Kullanıcı bilgilerini çek
$stmt = $pdo->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Kontrol Paneli - Hergün Pazar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f3f4f6;
        }
        .navbar {
            background-color: #1e90ff;
            padding: 1rem;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            margin-left: 1rem;
        }
        .dashboard {
            padding: 2rem;
            text-align: center;
        }
        .welcome-box {
            background: white;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: inline-block;
            margin-top: 2rem;
        }
        .logout-btn {
            background-color: #ff4d4f;
            color: white;
            padding: 10px 16px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }
        .logout-btn:hover {
            background-color: #e43d3f;
        }
    </style>
</head>
<body>

<div class="navbar">
    <div><strong>Hergün Pazar</strong> - Kullanıcı Paneli</div>
    <div>
        <a href="profile.php">Profilim</a>
        <a href="orders.php">Siparişlerim</a>
        <a href="logout.php" class="logout-btn">Çıkış Yap</a>
    </div>
</div>

<div class="dashboard">
    <div class="welcome-box">
        <h2>Hoş geldin, <span style="color: #1e90ff"><?= htmlspecialchars($user['username']) ?></span> 👋</h2>
        <p>Buradan siparişlerini takip edebilir, bilgilerini güncelleyebilirsin.</p>
    </div>
</div>

</body>
</html>
