<?php
session_start();
$isLoggedIn = isset($_SESSION['user_id']);
$username = $isLoggedIn ? $_SESSION['username'] : null;
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HergunPazar - Premium Alışveriş Deneyimi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-red: #FF6B6B; /* Kırmızı tonu */
            --primary-red-dark: #E55C5C;
            --primary-red-light: #FF8E8E;
            --accent-red: #FF5252;
            --white: #FFFFFF;
            --off-white: #FEFEFE;
            --light-gray: #F8F9FA;
            --gray-100: #F1F3F4;
            --gray-200: #E8EAED;
            --gray-300: #DADCE0;
            --gray-400: #BDC1C6;
            --gray-500: #9AA0A6;
            --gray-600: #5F6368;
            --gray-700: #3C4043;
            --gray-800: #202124;
            --gray-900: #1A1A1A;
            --success: #34A853;
            --danger: #EA4335;
            --warning: #FBBC04;
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
            --shadow-md: 0 4px 12px rgba(0,0,0,0.1);
            --shadow-lg: 0 10px 30px rgba(0,0,0,0.12);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --radius: 12px;
            --radius-sm: 8px;
            --radius-xs: 6px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: var(--light-gray);
            color: var(--gray-800);
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Notification Bar */
        .notification-bar {
            background: linear-gradient(135deg, var(--primary-red), var(--accent-red));
            color: var(--white);
            padding: 12px 0;
            font-size: 14px;
            position: relative;
            z-index: 1100;
            box-shadow: var(--shadow-sm);
        }

        .notification-content {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
        }

        .notification-message {
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 500;
        }

        .notification-icon {
            font-size: 18px;
            animation: bounce 2s infinite;
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
            40% { transform: translateY(-4px); }
            60% { transform: translateY(-2px); }
        }

        .notification-close {
            background: none;
            border: none;
            color: var(--white);
            cursor: pointer;
            padding: 8px;
            border-radius: var(--radius-xs);
            transition: var(--transition);
            opacity: 0.8;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .notification-close:hover {
            background: rgba(255, 255, 255, 0.1);
            opacity: 1;
            transform: rotate(90deg);
        }

        /* Main Navbar */
        .main-navbar {
            background: var(--white);
            box-shadow: var(--shadow-sm);
            position: sticky;
            top: 0;
            z-index: 1050;
            transition: var(--transition);
            border-bottom: 1px solid var(--gray-200);
        }

        .main-navbar.scrolled {
            box-shadow: var(--shadow-md);
        }

        .navbar-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1400px;
            margin: 0 auto;
            padding: 16px 24px;
        }

        /* Logo Section */
        .logo-section {
            display: flex;
            align-items: center;
            gap: 32px;
        }

        .brand-logo {
            display: flex;
            align-items: center;
            text-decoration: none;
            transition: var(--transition);
            gap: 12px;
        }

        .brand-logo:hover {
            transform: translateY(-2px);
        }

        .logo-circle {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--primary-red), var(--accent-red));
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
        }

        .brand-logo:hover .logo-circle {
            box-shadow: var(--shadow-md);
            transform: scale(1.05);
        }

        .logo-text {
            color: var(--white);
            font-size: 24px;
            font-weight: 700;
            font-family: 'Inter', sans-serif;
        }

        .brand-info {
            display: flex;
            flex-direction: column;
        }

        .brand-name {
            font-family: 'Inter', sans-serif;
            font-weight: 700;
            font-size: 24px;
            color: var(--gray-800);
            letter-spacing: -0.5px;
            line-height: 1;
        }

        .brand-tagline {
            font-family: 'Inter', sans-serif;
            font-size: 11px;
            color: var(--primary-red);
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-top: 2px;
        }

        /* Delivery Info */
        .delivery-info {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 16px;
            background: var(--gray-100);
            border-radius: var(--radius-sm);
            cursor: pointer;
            transition: var(--transition);
            border: 1px solid transparent;
        }

        .delivery-info:hover {
            background: var(--gray-200);
            border-color: var(--primary-red);
            transform: translateY(-1px);
        }

        .delivery-icon {
            color: var(--primary-red);
        }

        .delivery-text {
            font-family: 'Inter', sans-serif;
            font-size: 13px;
            font-weight: 500;
            color: var(--gray-700);
        }

        .delivery-arrow {
            color: var(--gray-500);
            transition: var(--transition);
        }

        .delivery-info:hover .delivery-arrow {
            color: var(--primary-red);
            transform: translateY(2px);
        }

        /* Search Bar */
        .search-container {
            flex: 1;
            max-width: 640px;
            margin: 0 32px;
            position: relative;
        }

        .search-form {
            display: flex;
            width: 100%;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 14px 20px;
            padding-right: 60px;
            border: 2px solid var(--gray-200);
            border-radius: var(--radius);
            font-family: 'Inter', sans-serif;
            font-size: 15px;
            color: var(--gray-800);
            background: var(--white);
            transition: var(--transition);
            outline: none;
        }

        .search-input:focus {
            border-color: var(--primary-red);
            box-shadow: 0 0 0 4px rgba(255, 107, 107, 0.2);
        }

        .search-input::placeholder {
            color: var(--gray-500);
        }

        .search-button {
            position: absolute;
            right: 4px;
            top: 4px;
            bottom: 4px;
            width: 48px;
            background: linear-gradient(135deg, var(--primary-red), var(--accent-red));
            color: var(--white);
            border: none;
            border-radius: var(--radius-sm);
            cursor: pointer;
            transition: var(--transition);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .search-button:hover {
            background: linear-gradient(135deg, var(--primary-red-dark), var(--primary-red));
            transform: scale(1.02);
        }

        /* Search Suggestions */
        .search-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background: var(--white);
            border-radius: 0 0 var(--radius) var(--radius);
            box-shadow: var(--shadow-lg);
            padding: 12px 0;
            z-index: 1000;
            border: 1px solid var(--gray-200);
            border-top: none;
            display: none;
            animation: fadeIn 0.2s ease-out;
        }

        @keyframes fadeIn {
            from { 
                opacity: 0; 
                transform: translateY(-8px); 
            }
            to { 
                opacity: 1; 
                transform: translateY(0); 
            }
        }

        .suggestion-item {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: var(--gray-700);
            text-decoration: none;
            transition: var(--transition);
            gap: 12px;
        }

        .suggestion-item:hover {
            background: var(--gray-100);
            color: var(--primary-red);
        }

        .suggestion-icon {
            color: var(--gray-400);
            flex-shrink: 0;
        }

        .suggestion-text {
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            line-height: 1.4;
        }

        /* User Actions */
        .user-actions {
            display: flex;
            gap: 24px;
            align-items: center;
        }

        .action-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-decoration: none;
            position: relative;
            padding: 8px 12px;
            transition: var(--transition);
            border-radius: var(--radius-sm);
        }

        .action-item:hover {
            background: var(--gray-100);
            transform: translateY(-2px);
        }

        .action-icon {
            color: var(--gray-600);
            margin-bottom: 4px;
            transition: var(--transition);
        }

        .action-item:hover .action-icon {
            color: var(--primary-red);
        }

        .action-label {
            font-family: 'Inter', sans-serif;
            font-size: 12px;
            font-weight: 500;
            color: var(--gray-500);
            transition: var(--transition);
        }

        .action-item:hover .action-label {
            color: var(--gray-700);
        }

        .action-badge {
            position: absolute;
            top: 2px;
            right: 6px;
            background: var(--danger);
            color: var(--white);
            font-size: 11px;
            font-weight: 600;
            padding: 2px 6px;
            border-radius: 12px;
            min-width: 20px;
            text-align: center;
            line-height: 1.2;
            border: 2px solid var(--white);
        }

        /* User Dropdown */
        .user-dropdown {
            position: relative;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
            padding: 8px 12px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }

        .user-profile:hover {
            background: var(--gray-100);
        }

        .user-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--primary-red);
            transition: var(--transition);
        }

        .user-profile:hover .user-avatar {
            border-color: var(--accent-red);
            transform: scale(1.05);
        }

        .user-name {
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            font-weight: 500;
            color: var(--gray-700);
            max-width: 120px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .user-dropdown-arrow {
            color: var(--gray-400);
            transition: var(--transition);
        }

        .user-profile:hover .user-dropdown-arrow {
            color: var(--primary-red);
            transform: translateY(2px);
        }

        /* Dropdown Menu */
        .dropdown-menu {
            position: absolute;
            right: 0;
            top: 100%;
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow-lg);
            padding: 16px 0;
            min-width: 260px;
            z-index: 1000;
            border: 1px solid var(--gray-200);
            display: none;
            animation: fadeIn 0.2s ease-out;
        }

        .user-dropdown:hover .dropdown-menu {
            display: block;
        }

        .dropdown-header {
            padding: 0 20px 16px;
            border-bottom: 1px solid var(--gray-200);
            margin-bottom: 12px;
        }

        .dropdown-user {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .dropdown-user-avatar {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--primary-red);
        }

        .dropdown-user-info {
            flex: 1;
        }

        .dropdown-user-name {
            font-family: 'Inter', sans-serif;
            font-weight: 600;
            font-size: 15px;
            color: var(--gray-800);
            margin-bottom: 2px;
        }

        .dropdown-user-email {
            font-family: 'Inter', sans-serif;
            font-size: 13px;
            color: var(--gray-500);
        }

        .dropdown-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 20px;
            color: var(--gray-700);
            text-decoration: none;
            transition: var(--transition);
            font-family: 'Inter', sans-serif;
            font-size: 14px;
        }

        .dropdown-item:hover {
            background: var(--gray-100);
            color: var(--primary-red);
        }

        .dropdown-badge {
            margin-left: auto;
            font-size: 12px;
            color: var(--primary-red);
            font-weight: 500;
        }

        .dropdown-divider {
            height: 1px;
            background: var(--gray-200);
            margin: 12px 0;
        }

        /* Category Bar */
        .category-bar {
            background: var(--white);
            border-bottom: 1px solid var(--gray-200);
            position: sticky;
            top: 73px;
            z-index: 1040;
            transition: var(--transition);
        }

        .category-bar.scrolled {
            top: 0;
            box-shadow: var(--shadow-sm);
        }

        .category-container {
            display: flex;
            gap: 20px;
            padding: 14px 24px;
            max-width: 1400px;
            margin: 0 auto;
            overflow-x: auto;
            scrollbar-width: none;
        }

        .category-container::-webkit-scrollbar {
            display: none;
        }

        /* Mega Menu */
        .mega-menu-trigger {
            position: relative;
        }

        .mega-menu-btn {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 18px;
            background: linear-gradient(135deg, var(--primary-red), var(--accent-red));
            color: var(--white);
            border-radius: var(--radius-sm);
            font-family: 'Inter', sans-serif;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            transition: var(--transition);
            box-shadow: var(--shadow-sm);
        }

        .mega-menu-btn:hover {
            background: linear-gradient(135deg, var(--primary-red-dark), var(--primary-red));
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .mega-menu {
            position: absolute;
            left: 0;
            right: 0;
            top: 100%;
            background: var(--white);
            box-shadow: var(--shadow-lg);
            padding: 32px;
            z-index: 1030;
            display: none;
            animation: fadeIn 0.3s ease-out;
            border: 1px solid var(--gray-200);
            margin-top: 8px;
            border-radius: var(--radius);
        }

        .mega-menu-trigger:hover .mega-menu {
            display: block;
        }

        .mega-menu-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 32px;
            max-width: 1400px;
            margin: 0 auto;
        }

        .mega-menu-column {
            display: flex;
            flex-direction: column;
            gap: 6px;
        }

        .mega-menu-title {
            display: flex;
            align-items: center;
            gap: 12px;
            font-family: 'Inter', sans-serif;
            font-weight: 700;
            font-size: 16px;
            color: var(--primary-red);
            margin-bottom: 16px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--gray-200);
        }

        .mega-menu-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 0;
            color: var(--gray-700);
            text-decoration: none;
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            transition: var(--transition);
            border-radius: var(--radius-xs);
        }

        .mega-menu-link:hover {
            color: var(--primary-red);
            padding-left: 8px;
            background: rgba(255, 107, 107, 0.05);
        }

        .mega-menu-banner {
            grid-column: span 2;
            background: linear-gradient(135deg, var(--gray-100), var(--gray-200));
            border-radius: var(--radius);
            padding: 28px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        .mega-menu-banner::before {
            content: '';
            position: absolute;
            top: -20px;
            right: -20px;
            width: 120px;
            height: 120px;
            background: linear-gradient(135deg, var(--primary-red), var(--accent-red));
            border-radius: 50%;
            filter: blur(60px);
            opacity: 0.15;
        }

        .mega-menu-banner img {
            max-width: 100%;
            height: 120px;
            object-fit: cover;
            margin-bottom: 20px;
            border-radius: var(--radius-sm);
        }

        .mega-menu-banner-title {
            font-family: 'Inter', sans-serif;
            font-weight: 700;
            font-size: 20px;
            color: var(--gray-800);
            margin-bottom: 10px;
        }

        .mega-menu-banner-text {
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            color: var(--gray-600);
            margin-bottom: 24px;
            line-height: 1.5;
        }

        .mega-menu-banner-btn {
            align-self: flex-start;
            background: linear-gradient(135deg, var(--primary-red), var(--accent-red));
            color: var(--white);
            padding: 12px 24px;
            border-radius: var(--radius);
            text-decoration: none;
            font-family: 'Inter', sans-serif;
            font-weight: 600;
            font-size: 14px;
            transition: var(--transition);
            box-shadow: var(--shadow-sm);
        }

        .mega-menu-banner-btn:hover {
            background: linear-gradient(135deg, var(--primary-red-dark), var(--primary-red));
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        /* Category Links */
        .category-link {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 10px 14px;
            color: var(--gray-700);
            text-decoration: none;
            font-family: 'Inter', sans-serif;
            font-weight: 500;
            font-size: 14px;
            white-space: nowrap;
            transition: var(--transition);
            border-radius: var(--radius-sm);
            position: relative;
        }

        .category-link:hover {
            color: var(--primary-red);
            background: rgba(255, 107, 107, 0.08);
            transform: translateY(-1px);
        }

        .category-badge {
            background: var(--danger);
            color: var(--white);
            font-size: 10px;
            font-weight: 600;
            padding: 3px 8px;
            border-radius: 12px;
            margin-left: 6px;
        }

        /* Main Content */
        .main-content {
            padding-top: 32px;
            flex: 1;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
        }

        .hero-section {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            padding: 48px;
            text-align: center;
            margin-bottom: 48px;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.9), rgba(255, 255, 255, 0.9)), 
                        url('https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&q=80&w=1000') center/cover;
        }

        .hero-title {
            font-family: 'Poppins', sans-serif;
            font-size: 48px;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 24px;
            line-height: 1.2;
        }

        .hero-subtitle {
            font-size: 20px;
            color: var(--gray-600);
            margin-bottom: 32px;
            line-height: 1.6;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
            background: rgba(255, 255, 255, 0.7);
            padding: 15px;
            border-radius: var(--radius);
        }

        /* Products Section */
        .products-section {
            background: var(--white);
            border-radius: var(--radius);
            box-shadow: var(--shadow-sm);
            padding: 32px;
            margin-bottom: 48px;
        }

        .section-title {
            font-family: 'Poppins', sans-serif;
            font-size: 28px;
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .section-title i {
            color: var(--primary-red);
        }

        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 24px;
        }

        .product-card {
            background: var(--white);
            border-radius: var(--radius);
            border: 1px solid var(--gray-200);
            overflow: hidden;
            transition: var(--transition);
            display: flex;
            flex-direction: column;
        }

        .product-card:hover {
            box-shadow: var(--shadow-md);
            transform: translateY(-5px);
            border-color: var(--primary-red);
        }

        .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
            background: linear-gradient(135deg, #f5f5f5, #e0e0e0);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--gray-400);
            font-size: 48px;
        }

        .product-info {
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .product-title {
            font-family: 'Inter', sans-serif;
            font-weight: 600;
            font-size: 16px;
            color: var(--gray-800);
            margin-bottom: 8px;
            flex: 1;
        }

        .product-price {
            font-family: 'Inter', sans-serif;
            font-weight: 700;
            font-size: 18px;
            color: var(--gray-900);
            margin-bottom: 16px;
        }

        .product-actions {
            display: flex;
            gap: 8px;
        }

        .add-to-cart {
            flex: 1;
            background: linear-gradient(135deg, var(--primary-red), var(--accent-red));
            color: var(--white);
            border: none;
            padding: 10px;
            border-radius: var(--radius-sm);
            font-family: 'Inter', sans-serif;
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
        }

        .add-to-cart:hover {
            background: linear-gradient(135deg, var(--primary-red-dark), var(--primary-red));
        }

        .add-to-wishlist {
            width: 40px;
            height: 40px;
            background: var(--gray-100);
            border: none;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: var(--transition);
        }

        .add-to-wishlist:hover {
            background: var(--gray-200);
            color: var(--danger);
        }

        /* Footer */
        .footer {
            background: var(--gray-900);
            color: var(--gray-200);
            padding: 60px 0 30px;
            margin-top: auto;
        }

        .footer-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 40px;
        }

        .footer-about {
            grid-column: span 2;
        }

        .footer-title {
            font-family: 'Poppins', sans-serif;
            font-size: 20px;
            font-weight: 700;
            color: var(--white);
            margin-bottom: 20px;
            position: relative;
            padding-bottom: 12px;
        }

        .footer-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background: var(--primary-red);
            border-radius: 3px;
        }

        .footer-about-text {
            margin-bottom: 24px;
            line-height: 1.7;
        }

        .contact-info {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }

        .contact-icon {
            color: var(--primary-red);
            margin-top: 4px;
        }

        .social-links {
            display: flex;
            gap: 16px;
            margin-top: 20px;
        }

        .social-link {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            color: var(--white);
            transition: var(--transition);
        }

        .social-link:hover {
            background: var(--primary-red);
            color: var(--white);
            transform: translateY(-3px);
        }

        .footer-links {
            display: flex;
            flex-direction: column;
            gap: 14px;
        }

        .footer-link {
            color: var(--gray-300);
            text-decoration: none;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .footer-link:hover {
            color: var(--primary-red);
            padding-left: 5px;
        }

        .footer-link i {
            font-size: 12px;
        }

        .copyright {
            text-align: center;
            padding-top: 30px;
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: var(--gray-400);
            font-size: 14px;
        }

        /* Responsive Design */
        @media (max-width: 1200px) {
            .delivery-info {
                display: none;
            }
            
            .search-container {
                margin: 0 20px;
            }
        }

        @media (max-width: 992px) {
            .mega-menu-grid {
                grid-template-columns: repeat(4, 1fr);
            }
            
            .mega-menu-banner {
                grid-column: span 4;
            }

            .footer-about {
                grid-column: span 3;
            }
        }

        @media (max-width: 768px) {
            .navbar-container {
                flex-wrap: wrap;
                padding-bottom: 0;
            }
            
            .search-container {
                order: 3;
                margin: 16px 0 0;
                width: 100%;
            }
            
            .category-bar {
                top: 130px;
            }
            
            .category-bar.scrolled {
                top: 60px;
            }
            
            .mega-menu-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .mega-menu-banner {
                grid-column: span 2;
            }
            
            .logo-section {
                gap: 16px;
            }
            
            .user-actions {
                gap: 16px;
            }

            .hero-title {
                font-size: 36px;
            }

            .hero-subtitle {
                font-size: 18px;
            }

            .hero-section {
                padding: 32px 24px;
            }

            .products-grid {
                grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            }
        }
    </style>
</head>
<body>
    <?php
    // Mock session data for demonstration
    session_start();
    $cartCount = 3;
    $wishlistCount = 7;
    $userLoggedIn = true;
    $_SESSION['user'] = [
        'name' => 'Ahmet Yılmaz',
        'email' => 'ahmet@example.com',
        'avatar' => 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=64'
    ];
    ?>

    <!-- Notification Bar -->
    <div class="notification-bar" id="notificationBar">
        <div class="notification-content">
            <div class="notification-message">
                <span class="notification-icon">🎉</span>
                <span>Özel Fırsat! 500 TL ve üzeri alışverişlerde 75 TL indirim. Kupon kodu: <strong>PREMIUM75</strong></span>
            </div>
            <button class="notification-close" onclick="closeNotification()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>

    <!-- Main Navbar -->
    <nav class="main-navbar" id="mainNavbar">
        <div class="navbar-container">
            <!-- Logo Section -->
            <div class="logo-section">
                <a href="index.php" class="brand-logo">
                    <div class="logo-circle">
                        <span class="logo-text">H</span>
                    </div>
                    <div class="brand-info">
                        <div class="brand-name">HergunPazar</div>
                        <div class="brand-tagline">ELİT ALIŞVERİŞ DENEYİMİ</div>
                    </div>
                </a>
                
                <div class="delivery-info">
                    <i class="fas fa-map-marker-alt delivery-icon"></i>
                    <span class="delivery-text">Teslimat Adresi Belirle</span>
                    <i class="fas fa-chevron-down delivery-arrow"></i>
                </div>
            </div>

            <!-- Search Bar -->
            <div class="search-container">
                <form class="search-form" action="search.php" method="GET">
                    <input type="text" class="search-input" name="q" placeholder="Premium ürünlerde arama yapın..." autocomplete="off" onfocus="showSuggestions()" onblur="hideSuggestions()">
                    <button type="submit" class="search-button">
                        <i class="fas fa-search"></i>
                    </button>
                    
                    <!-- Search Suggestions -->
                    <div class="search-suggestions" id="searchSuggestions">
                        <a href="#" class="suggestion-item">
                            <i class="fas fa-search suggestion-icon"></i>
                            <span class="suggestion-text">En popüler <strong>iPhone 15 Pro</strong> modelleri</span>
                        </a>
                        <a href="#" class="suggestion-item">
                            <i class="fas fa-search suggestion-icon"></i>
                            <span class="suggestion-text"><strong>MacBook</strong> Air M2 2023</span>
                        </a>
                        <a href="#" class="suggestion-item">
                            <i class="fas fa-search suggestion-icon"></i>
                            <span class="suggestion-text"><strong>Apple Watch</strong> Series 9</span>
                        </a>
                        <a href="#" class="suggestion-item">
                            <i class="fas fa-tag suggestion-icon"></i>
                            <span class="suggestion-text"><strong>Apple</strong> kategorisinde arama yap</span>
                        </a>
                    </div>
                </form>
            </div>

            <!-- User Actions -->
            <div class="user-actions">
                <?php if($userLoggedIn): ?>
                    <!-- User Dropdown -->
                    <div class="user-dropdown">
                        <div class="user-profile">
                            <img src="<?= $_SESSION['user']['avatar'] ?>" class="user-avatar" alt="Profil">
                            <span class="user-name"><?= $_SESSION['user']['name'] ?></span>
                            <i class="fas fa-chevron-down user-dropdown-arrow"></i>
                        </div>
                        
                        <!-- Dropdown Menu -->
                        <div class="dropdown-menu">
                            <div class="dropdown-header">
                                <div class="dropdown-user">
                                    <img src="<?= $_SESSION['user']['avatar'] ?>" class="dropdown-user-avatar" alt="Profil">
                                    <div class="dropdown-user-info">
                                        <div class="dropdown-user-name"><?= $_SESSION['user']['name'] ?></div>
                                        <div class="dropdown-user-email"><?= $_SESSION['user']['email'] ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <a href="profile.php" class="dropdown-item">
                                <i class="fas fa-user"></i>
                                <span>Profilim</span>
                            </a>
                            <a href="orders.php" class="dropdown-item">
                                <i class="fas fa-shopping-bag"></i>
                                <span>Siparişlerim</span>
                            </a>
                            <a href="wishlist.php" class="dropdown-item">
                                <i class="far fa-heart"></i>
                                <span>Favorilerim</span>
                                <?php if($wishlistCount > 0): ?>
                                    <span class="dropdown-badge"><?= $wishlistCount ?></span>
                                <?php endif; ?>
                            </a>
                            
                            <div class="dropdown-divider"></div>
                            
                            <a href="coupons.php" class="dropdown-item">
                                <i class="fas fa-tag"></i>
                                <span>Kuponlarım</span>
                                <span class="dropdown-badge">3 Yeni</span>
                            </a>
                            <a href="messages.php" class="dropdown-item">
                                <i class="fas fa-envelope"></i>
                                <span>Mesajlarım</span>
                                <span class="dropdown-badge">2 Okunmamış</span>
                            </a>
                            
                            <div class="dropdown-divider"></div>
                            
                            <a href="settings.php" class="dropdown-item">
                                <i class="fas fa-cog"></i>
                                <span>Hesap Ayarları</span>
                            </a>
                            <a href="logout.php" class="dropdown-item">
                                <i class="fas fa-sign-out-alt"></i>
                                <span>Çıkış Yap</span>
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Login/Register -->
                    <a href="login.php" class="action-item">
                        <i class="far fa-user action-icon"></i>
                        <span class="action-label">Giriş Yap</span>
                    </a>
                <?php endif; ?>
                
                <!-- Wishlist -->
                <a href="wishlist.php" class="action-item">
                    <i class="far fa-heart action-icon"></i>
                    <span class="action-label">Favoriler</span>
                    <?php if($wishlistCount > 0): ?>
                        <span class="action-badge"><?= $wishlistCount ?></span>
                    <?php endif; ?>
                </a>
                
                <!-- Cart -->
                <a href="cart.php" class="action-item">
                    <i class="fas fa-shopping-bag action-icon"></i>
                    <span class="action-label">Sepetim</span>
                    <?php if($cartCount > 0): ?>
                        <span class="action-badge"><?= $cartCount ?></span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </nav>

    <!-- Category Bar with Mega Menu -->
    <div class="category-bar" id="categoryBar">
        <div class="category-container">
            <!-- Mega Menu Trigger -->
            <div class="mega-menu-trigger">
                <a href="#" class="mega-menu-btn">
                    <i class="fas fa-bars"></i>
                    <span>Tüm Kategoriler</span>
                </a>
                
                <!-- Mega Menu Content -->
                <div class="mega-menu">
                    <div class="mega-menu-grid">
                        <!-- Column 1 - Electronics -->
                        <div class="mega-menu-column">
                            <h4 class="mega-menu-title">
                                <i class="fas fa-laptop"></i>
                                <span>Elektronik</span>
                            </h4>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Akıllı Telefonlar</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Bilgisayarlar</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Televizyonlar</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Kulaklıklar</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Tabletler</span>
                            </a>
                        </div>
                        
                        <!-- Column 2 - Fashion -->
                        <div class="mega-menu-column">
                            <h4 class="mega-menu-title">
                                <i class="fas fa-tshirt"></i>
                                <span>Moda</span>
                            </h4>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Erkek Giyim</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Kadın Giyim</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Ayakkabı</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Çanta</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Saat & Aksesuar</span>
                            </a>
                        </div>
                        
                        <!-- Column 3 - Home -->
                        <div class="mega-menu-column">
                            <h4 class="mega-menu-title">
                                <i class="fas fa-home"></i>
                                <span>Ev & Yaşam</span>
                            </h4>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Mobilya</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Ev Tekstili</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Mutfak</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Banyo</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Aydınlatma</span>
                            </a>
                        </div>
                        
                        <!-- Column 4 - Beauty -->
                        <div class="mega-menu-column">
                            <h4 class="mega-menu-title">
                                <i class="fas fa-spa"></i>
                                <span>Kozmetik</span>
                            </h4>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Parfüm</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Makyaj</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Cilt Bakımı</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Saç Bakımı</span>
                            </a>
                            <a href="#" class="mega-menu-link">
                                <i class="fas fa-chevron-right"></i>
                                <span>Erkek Bakım</span>
                            </a>
                        </div>
                        
                        <!-- Banner Column -->
                        <div class="mega-menu-banner">
                            <img src="https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=400" alt="Özel Fırsat">
                            <h3 class="mega-menu-banner-title">Premium Üyelere Özel</h3>
                            <p class="mega-menu-banner-text">Premium üyelerimiz için özel indirimler ve avantajlarla dolu yeni sezon fırsatları!</p>
                            <a href="#" class="mega-menu-banner-btn">Keşfet</a>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Category Links -->
            <a href="category.php?cat=electronics" class="category-link">
                <i class="fas fa-laptop"></i>
                <span>Elektronik</span>
            </a>
            
            <a href="category.php?cat=women-fashion" class="category-link">
                <i class="fas fa-female"></i>
                <span>Kadın</span>
            </a>
            
            <a href="category.php?cat=men-fashion" class="category-link">
                <i class="fas fa-male"></i>
                <span>Erkek</span>
            </a>
            
            <a href="category.php?cat=home-living" class="category-link">
                <i class="fas fa-home"></i>
                <span>Ev & Yaşam</span>
            </a>
            
            <a href="category.php?cat=beauty" class="category-link">
                <i class="fas fa-spa"></i>
                <span>Kozmetik</span>
            </a>
            
            <a href="category.php?cat=sports" class="category-link">
                <i class="fas fa-running"></i>
                <span>Spor & Outdoor</span>
            </a>
            
            <a href="category.php?cat=premium" class="category-link">
                <i class="fas fa-crown"></i>
                <span>Premium Ürünler</span>
                <span class="category-badge">Yeni</span>
            </a>
            
            <a href="campaigns.php" class="category-link">
                <i class="fas fa-percentage"></i>
                <span>Kampanyalar</span>
            </a>
            
            <a href="brands.php" class="category-link">
                <i class="fas fa-star"></i>
                <span>Lüks Markalar</span>
            </a>
        </div>
    </div>

               <!-- Products Section -->
            <section class="products-section">
                <h2 class="section-title">
                    <i class="fas fa-star"></i>
                    Öne Çıkan Ürünler
                </h2>
                <div class="products-grid">
                    <!-- Product 1 -->
                    <div class="product-card">
                        <div class="product-image">
                            <i class="fas fa-mobile-alt"></i>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">iPhone 15 Pro Max 256GB</h3>
                            <div class="product-price">34.999 TL</div>
                            <div class="product-actions">
                                <button class="add-to-cart">Sepete Ekle</button>
                                <button class="add-to-wishlist">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product 2 -->
                    <div class="product-card">
                        <div class="product-image">
                            <i class="fas fa-laptop"></i>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">MacBook Air M2 13.6"</h3>
                            <div class="product-price">27.499 TL</div>
                            <div class="product-actions">
                                <button class="add-to-cart">Sepete Ekle</button>
                                <button class="add-to-wishlist">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product 3 -->
                    <div class="product-card">
                        <div class="product-image">
                            <i class="fas fa-headphones"></i>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Sony WH-1000XM5 Kablosuz Kulaklık</h3>
                            <div class="product-price">8.499 TL</div>
                            <div class="product-actions">
                                <button class="add-to-cart">Sepete Ekle</button>
                                <button class="add-to-wishlist">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product 4 -->
                    <div class="product-card">
                        <div class="product-image">
                            <i class="fas fa-camera"></i>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Sony Alpha A7 IV Full Frame Kamera</h3>
                            <div class="product-price">52.999 TL</div>
                            <div class="product-actions">
                                <button class="add-to-cart">Sepete Ekle</button>
                                <button class="add-to-wishlist">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product 5 -->
                    <div class="product-card">
                        <div class="product-image">
                            <i class="fas fa-watch"></i>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">Apple Watch Ultra 2</h3>
                            <div class="product-price">14.999 TL</div>
                            <div class="product-actions">
                                <button class="add-to-cart">Sepete Ekle</button>
                                <button class="add-to-wishlist">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Product 6 -->
                    <div class="product-card">
                        <div class="product-image">
                            <i class="fas fa-tablet-alt"></i>
                        </div>
                        <div class="product-info">
                            <h3 class="product-title">iPad Pro 12.9" M2 Çip</h3>
                            <div class="product-price">22.999 TL</div>
                            <div class="product-actions">
                                <button class="add-to-cart">Sepete Ekle</button>
                                <button class="add-to-wishlist">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="footer-container">
            <div class="footer-about">
                <h3 class="footer-title">Hakkımızda</h3>
                <p class="footer-about-text">
                    HergunPazar, 2020 yılından bu yana müşterilerine premium alışveriş deneyimi sunan 
                    bir e-ticaret platformudur. En kaliteli ürünleri, en uygun fiyatlarla sunarak 
                    müşteri memnuniyetini her zaman ön planda tutuyoruz.
                </p>
                <div class="contact-info">
                    <div class="contact-item">
                        <i class="fas fa-map-marker-alt contact-icon"></i>
                        <span>Levent Mah. No:123, 34330 Beşiktaş/İstanbul</span>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-phone-alt contact-icon"></i>
                        <span>0 (212) 345 67 89</span>
                    </div>
                    <div class="contact-item">
                        <i class="fas fa-envelope contact-icon"></i>
                        <span>info@hergunpazar.com</span>
                    </div>
                </div>
                <div class="social-links">
                    <a href="#" class="social-link">
                        <i class="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" class="social-link">
                        <i class="fab fa-twitter"></i>
                    </a>
                    <a href="#" class="social-link">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="#" class="social-link">
                        <i class="fab fa-youtube"></i>
                    </a>
                </div>
            </div>
            
            <div class="footer-links-section">
                <h3 class="footer-title">Hızlı Erişim</h3>
                <div class="footer-links">
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>Kampanyalar</span>
                    </a>
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>Yeni Ürünler</span>
                    </a>
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>Çok Satanlar</span>
                    </a>
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>Premium Üyelik</span>
                    </a>
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>İndirim Kuponları</span>
                    </a>
                </div>
            </div>
            
            <div class="footer-links-section">
                <h3 class="footer-title">Müşteri Hizmetleri</h3>
                <div class="footer-links">
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>Sipariş Takibi</span>
                    </a>
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>İade & Değişim</span>
                    </a>
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>Kargo & Teslimat</span>
                    </a>
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>Ödeme Seçenekleri</span>
                    </a>
                    <a href="#" class="footer-link">
                        <i class="fas fa-chevron-right"></i>
                        <span>Sıkça Sorulan Sorular</span>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="copyright">
            &copy; 2023 HergunPazar. Tüm hakları saklıdır.
        </div>
    </footer>

    <!-- JavaScript -->
    <script>
        // Sticky Navbar Behavior
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('mainNavbar');
            const categoryBar = document.getElementById('categoryBar');
            const scrollPosition = window.scrollY;
            
            if (scrollPosition > 20) {
                navbar.classList.add('scrolled');
                categoryBar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
                categoryBar.classList.remove('scrolled');
            }
        });

        // Close Notification
        function closeNotification() {
            document.getElementById('notificationBar').style.display = 'none';
        }

        // Search Suggestions
        function showSuggestions() {
            document.getElementById('searchSuggestions').style.display = 'block';
        }

        function hideSuggestions() {
            setTimeout(() => {
                document.getElementById('searchSuggestions').style.display = 'none';
            }, 200);
        }

        // Click outside to close suggestions
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.search-container')) {
                document.getElementById('searchSuggestions').style.display = 'none';
            }
        });

        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Add to cart button animation
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function() {
                this.innerHTML = '<i class="fas fa-check"></i> Eklendi';
                this.style.background = 'var(--success)';
                
                setTimeout(() => {
                    this.innerHTML = 'Sepete Ekle';
                    this.style.background = 'linear-gradient(135deg, var(--primary-red), var(--accent-red))';
                }, 2000);
            });
        });
    </script>
</body>
</html>